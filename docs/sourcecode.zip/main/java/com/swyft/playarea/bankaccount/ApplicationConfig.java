package com.swyft.playarea.bankaccount;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
public class ApplicationConfig {

    @Value("${app.validationsFeatureToggleEnabled}")
    private boolean isValidationEnabled;

}
