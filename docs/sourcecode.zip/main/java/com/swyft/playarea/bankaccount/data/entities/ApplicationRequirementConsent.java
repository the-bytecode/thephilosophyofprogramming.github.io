package com.swyft.playarea.bankaccount.data.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "application_requirement_consent", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationRequirementConsent extends BaseEntity {
    
    @Column(name = "application_id", nullable = false, length = 36)
    private String applicationId;
    
    @Column(name = "requirement_id", nullable = false, length = 36)
    private String requirementId;
    
    @Column(name = "consent_given", nullable = false)
    private Boolean consentGiven = false;
    
    @Column(name = "consent_date")
    private LocalDateTime consentDate;
    
    @Column(name = "ip_address", length = 50)
    private String ipAddress;
    
    @Column(name = "user_agent", length = 500)
    private String userAgent;
}
