package com.swyft.playarea.bankaccount.controller;

import com.swyft.playarea.bankaccount.service.BankService;
import com.swyft.playarea.bankaccount.service.ProductService;
import com.swyft.playarea.bankaccount.service.dto.BankDTO;
import com.swyft.playarea.bankaccount.service.dto.ProductDTO;
import com.swyft.playarea.bankaccount.service.dto.ProductDocumentTypeDTO;
import com.swyft.playarea.bankaccount.service.dto.ProductRequirementDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/banks")
@RequiredArgsConstructor
@Tag(name = "Banks and Products", description = "API endpoints for bank and product management")
public class BankProductController {

    private final BankService bankService;
    private final ProductService productService;

    @Operation(summary = "Get all banks", description = "Retrieves a list of all active banks")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Banks retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = BankDTO.class, type = "array"))})
    })
    @GetMapping
    public List<BankDTO> getAllBanks() {
        return bankService.getAllActiveBanks();
    }

    @Operation(summary = "Get bank by ID", description = "Retrieves bank information by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Bank found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = BankDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Bank not found")
    })
    @GetMapping("/{bankId}")
    public BankDTO getBankById(@PathVariable String bankId) {
        return bankService.getBankById(bankId);
    }

    @Operation(summary = "Get bank with product hierarchy", description = "Retrieves bank information with complete product hierarchy")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Bank with product hierarchy found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = BankDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Bank not found")
    })
    @GetMapping("/{bankId}/product-hierarchy")
    public BankDTO getBankWithProductHierarchy(@PathVariable String bankId) {
        return bankService.getBankWithProductHierarchy(bankId);
    }

    @Operation(summary = "Get products by bank", description = "Retrieves all products offered by a specific bank")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Products retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ProductDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Bank not found")
    })
    @GetMapping("/{bankId}/products")
    public List<ProductDTO> getProductsByBank(@PathVariable String bankId) {
        return productService.getProductsByBank(bankId);
    }

    @Operation(summary = "Get product by ID", description = "Retrieves product information by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Product found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ProductDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Product not found")
    })
    @GetMapping("/{bankId}/products/{productId}")
    public ProductDTO getProductById(@PathVariable String productId, @PathVariable String bankId) {
        return productService.getProductById(productId);
    }

    @Operation(summary = "Get product with children", description = "Retrieves product with its sub-products hierarchy")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Product hierarchy found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ProductDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Product not found")
    })
    @GetMapping("/{bankId}/products/{productId}/product-hierarchy")
    public ProductDTO getProductWithChildren(@PathVariable String productId, @PathVariable String bankId) {
        return productService.getProductWithChildren(productId);
    }

    @Operation(summary = "Get requirements by product", description = "Retrieves all requirements for a specific product")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Requirements retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ProductRequirementDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Product not found")
    })
    @GetMapping("/{bankId}/products/{productId}/requirements")
    public List<ProductRequirementDTO> getRequirementsByProduct(@PathVariable String productId, @PathVariable String bankId) {
        return productService.getRequirementsByProduct(productId);
    }

    @Operation(summary = "Get documents by product", description = "Retrieves all document types required for a specific product")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Document types retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ProductDocumentTypeDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Product not found")
    })
    @GetMapping("/{bankId}/products/{productId}/documents")
    public List<ProductDocumentTypeDTO> getDocumentsByProduct(@PathVariable String productId, @PathVariable String bankId) {
        return productService.getDocumentTypesByProduct(productId);
    }

    @Operation(summary = "Get product with full details", description = "Retrieves product with requirements and document types")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Product details found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ProductDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Product not found")
    })
    @GetMapping("/{bankId}/products/{productId}/details")
    public ProductDTO getProductWithRequirementsAndDocuments(@PathVariable String productId, @PathVariable String bankId) {
        return productService.getProductWithRequirementsAndDocuments(productId);
    }
}