package com.swyft.playarea.bankaccount.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse<T> {
    private T data;
    private String message;
    
    @Builder.Default
    private List<String> errors = new ArrayList<>();
    
    public static <T> ApiResponse<T> success(T data) {
        return ApiResponse.<T>builder()
                .data(data)
                .message("Success")
                .build();
    }
    
    public static <T> ApiResponse<T> success(T data, String message) {
        return ApiResponse.<T>builder()
                .data(data)
                .message(message)
                .build();
    }
    
    public static ApiResponse<Void> error(String message) {
        return ApiResponse.<Void>builder()
                .message(message)
                .build();
    }
    
    public static ApiResponse<Void> error(String message, List<String> errors) {
        return ApiResponse.<Void>builder()
                .message(message)
                .errors(errors)
                .build();
    }
}
