package com.swyft.playarea.bankaccount.event;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DocumentVerifiedEvent {
    private final String applicationId;
    private final String documentId;
    private final Boolean isVerified;
    private final String verifiedBy;
}