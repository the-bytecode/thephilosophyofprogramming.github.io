package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentRepository extends JpaRepository<Document, String> {
    
    List<Document> findByApplicationId(String applicationId);
    
    List<Document> findByApplicationIdAndDocumentTypeId(String applicationId, String documentTypeId);
    
    List<Document> findByApplicationIdAndIsVerified(String applicationId, Boolean isVerified);
}
