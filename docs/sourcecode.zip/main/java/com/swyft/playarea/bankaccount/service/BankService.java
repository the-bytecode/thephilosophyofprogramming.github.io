package com.swyft.playarea.bankaccount.service;


import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.data.entities.Bank;

import com.swyft.playarea.bankaccount.data.repository.BankRepository;
import com.swyft.playarea.bankaccount.service.dto.BankDTO;
import com.swyft.playarea.bankaccount.service.mapper.BankMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BankService {
    
    private final BankRepository bankRepository;
    private final BankMapper bankMapper;
    private final ProductService productService;
    
    @Transactional(readOnly = true)
    public List<BankDTO> getAllActiveBanks() {
        List<Bank> banks = bankRepository.findByActiveTrue();
        return banks.stream()
                .map(bankMapper::toDto)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public BankDTO getBankById(String id) {
        Bank bank = bankRepository.findById(id)
                .orElseThrow(() -> new PlatformException("Bank not found with id: " + id));
        
        BankDTO bankDTO = bankMapper.toDto(bank);
        
        // Fetch the top-level products for this bank
        bankDTO.setProducts(productService.getProductsByBank(id));
        
        return bankDTO;
    }
    
    @Transactional(readOnly = true)
    public BankDTO getBankByCode(String code) {
        Bank bank = bankRepository.findByCode(code)
                .orElseThrow(() -> new PlatformException("Bank not found with code: " + code));
        
        BankDTO bankDTO = bankMapper.toDto(bank);
        
        // Fetch the top-level products for this bank
        bankDTO.setProducts(productService.getProductsByBank(bank.getId()));
        
        return bankDTO;
    }
    
    @Transactional(readOnly = true)
    public BankDTO getBankWithProductHierarchy(String bankId) {
        Bank bank = bankRepository.findById(bankId)
                .orElseThrow(() -> new PlatformException("Bank not found with id: " + bankId));
        
        BankDTO bankDTO = bankMapper.toDto(bank);
        
        // Fetch the complete product hierarchy for this bank
        bankDTO.setProducts(productService.getProductHierarchyByBank(bankId));
        
        return bankDTO;
    }
}
