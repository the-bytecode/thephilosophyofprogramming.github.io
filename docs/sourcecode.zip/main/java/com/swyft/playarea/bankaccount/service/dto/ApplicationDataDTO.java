package com.swyft.playarea.bankaccount.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@AllArgsConstructor
@Builder
@Getter
public class ApplicationDataDTO {
    private ApplicationDTO application;
    private CustomerDTO customer;
}
