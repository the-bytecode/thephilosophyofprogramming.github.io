package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.ProductRequirement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRequirementRepository extends JpaRepository<ProductRequirement, String> {
    
    List<ProductRequirement> findByProductId(String productId);
    
    List<ProductRequirement> findByProductIdAndIsMandatory(String productId, Boolean isMandatory);
    
    List<ProductRequirement> findByRequirementId(String requirementId);
}
