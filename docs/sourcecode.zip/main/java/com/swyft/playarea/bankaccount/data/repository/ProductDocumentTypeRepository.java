package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.ProductDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductDocumentTypeRepository extends JpaRepository<ProductDocumentType, String> {
    
    List<ProductDocumentType> findByProductId(String productId);
    
    List<ProductDocumentType> findByProductIdAndIsMandatory(String productId, Boolean isMandatory);
    
    List<ProductDocumentType> findByDocumentTypeId(String documentTypeId);
}
