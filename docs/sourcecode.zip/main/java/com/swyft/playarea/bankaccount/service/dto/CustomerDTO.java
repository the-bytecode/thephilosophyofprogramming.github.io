package com.swyft.playarea.bankaccount.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@Getter
public class CustomerDTO {
    private String id;
    private String firstname;
    private String lastname;
    private String email;
    private String phone;
    private AddressDTO address;
    private String ssn;
    private LocalDate dob;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
