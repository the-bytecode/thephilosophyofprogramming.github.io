package com.swyft.playarea.bankaccount.controller.model;

import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@Getter
public class ApplicationResponse {
    private String applicationId;
    private String applicationNumber;
    private String productId;
    private ApplicationStatus status;
    private LocalDateTime createdOn;
}
