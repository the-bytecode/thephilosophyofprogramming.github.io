package com.swyft.playarea.bankaccount.service;


import com.swyft.playarea.bankaccount.data.entities.AcceptedDocument;
import com.swyft.playarea.bankaccount.data.repository.AcceptedDocumentRepository;
import com.swyft.playarea.bankaccount.service.dto.AcceptedDocumentDTO;
import com.swyft.playarea.bankaccount.service.mapper.AcceptedDocumentMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class AcceptedDocumentService {

    private final AcceptedDocumentRepository acceptedDocumentRepository;
    private final AcceptedDocumentMapper acceptedDocumentMapper;


    /**
     * Find an AcceptedDocument by its code
     *
     * @param code The document code
     * @return Optional containing the DTO if found
     */
    public Optional<AcceptedDocumentDTO> findByCode(String code) {
        return acceptedDocumentRepository.findByCode(code)
                .map(acceptedDocumentMapper::toDTO);
    }

    /**
     * Find an AcceptedDocument by its ID
     *
     * @param id The document ID
     * @return Optional containing the DTO if found
     */
    public Optional<AcceptedDocumentDTO> findById(String id) {
        return acceptedDocumentRepository.findById(id)
                .map(acceptedDocumentMapper::toDTO);
    }

    /**
     * Get all active AcceptedDocuments
     *
     * @return List of active document DTOs
     */
    public List<AcceptedDocumentDTO> findAllActive() {
        return acceptedDocumentRepository.findByIsActiveTrue().stream()
                .map(acceptedDocumentMapper::toDTO)
                .collect(Collectors.toList());
    }

    /**
     * Find all AcceptedDocuments for a specific document type
     *
     * @param documentTypeId The document type ID
     * @return List of document DTOs
     */
    public List<AcceptedDocumentDTO> findByDocumentTypeId(String documentTypeId) {
        return acceptedDocumentRepository.findByDocumentTypeId(documentTypeId).stream()
                .map(acceptedDocumentMapper::toDTO)
                .collect(Collectors.toList());
    }

    /**
     * Deactivate an AcceptedDocument instead of deleting
     *
     * @param id The document ID to deactivate
     * @return The updated document as DTO
     */
    @Transactional
    public Optional<AcceptedDocumentDTO> deactivate(String id) {
        return acceptedDocumentRepository.findById(id)
                .map(document -> {
                    document.setIsActive(false);
                    AcceptedDocument savedDocument = acceptedDocumentRepository.save(document);
                    return acceptedDocumentMapper.toDTO(savedDocument);
                });
    }
}
