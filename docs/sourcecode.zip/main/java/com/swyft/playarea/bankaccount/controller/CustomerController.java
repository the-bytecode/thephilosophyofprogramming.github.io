package com.swyft.playarea.bankaccount.controller;


import com.swyft.playarea.bankaccount.service.CustomerService;
import com.swyft.playarea.bankaccount.service.dto.CustomerDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/customers")
@RequiredArgsConstructor
@Tag(name = "Customers", description = "API endpoints for managing customer information")
public class CustomerController {

    private final CustomerService customerService;

    @Operation(summary = "Get customer by ID", description = "Retrieves customer information by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer found",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = CustomerDTO.class)) }),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    @GetMapping("/{customerId}")
    public CustomerDTO getCustomerById(@PathVariable String customerId) {
        return customerService.findCustomerById(customerId);
    }

    @Operation(summary = "Get customer by SSN", description = "Retrieves customer information by Social Security Number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer found",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = CustomerDTO.class)) }),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    @GetMapping("/ssn/{ssn}")
    public CustomerDTO getCustomerBySsn(@PathVariable String ssn) {
        return customerService.findCustomerBySsn(ssn);
    }

    @Operation(summary = "Get customer by phone number", description = "Retrieves customer information by phone number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Customer found",
                    content = { @Content(mediaType = "application/json",
                            schema = @Schema(implementation = CustomerDTO.class)) }),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    @GetMapping("/phone/{phoneNumber}")
    public CustomerDTO getCustomerByPhoneNumber(@PathVariable String phoneNumber) {
        return customerService.findCustomerByPhoneNumber(phoneNumber);
    }

}
