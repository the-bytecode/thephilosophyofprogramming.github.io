package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.Requirement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RequirementRepository extends JpaRepository<Requirement, String> {
    
    Optional<Requirement> findByCode(String code);
    
    @Query("SELECT r FROM Requirement r JOIN ProductRequirement pr ON r.id = pr.requirementId WHERE pr.productId = :productId")
    List<Requirement> findByProductId(@Param("productId") String productId);
    
    @Query("SELECT r FROM Requirement r JOIN ProductRequirement pr ON r.id = pr.requirementId WHERE pr.productId = :productId AND pr.isMandatory = true")
    List<Requirement> findMandatoryByProductId(@Param("productId") String productId);
}
