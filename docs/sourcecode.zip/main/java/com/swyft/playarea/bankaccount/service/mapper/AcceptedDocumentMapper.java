package com.swyft.playarea.bankaccount.service.mapper;

import com.swyft.playarea.bankaccount.data.entities.AcceptedDocument;
import com.swyft.playarea.bankaccount.service.dto.AcceptedDocumentDTO;
import org.springframework.stereotype.Component;

@Component
public class AcceptedDocumentMapper {
    public AcceptedDocumentDTO toDTO(AcceptedDocument acceptedDocument) {
        return AcceptedDocumentDTO.builder()
                .id(acceptedDocument.getId())
                .name(acceptedDocument.getName())
                .code(acceptedDocument.getCode())
                .isActive(acceptedDocument.getIsActive())
                .description(acceptedDocument.getDescription())
                .build();
    }
}
