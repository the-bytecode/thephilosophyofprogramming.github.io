package com.swyft.playarea.bankaccount.service.dto;

import com.swyft.playarea.bankaccount.service.dto.ProductDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BankDTO {
    
    private String id;
    private String name;
    private String code;
    private LocalDate establishedDate;
    private Boolean active;
    
    // For nested responses
    private List<ProductDTO> products;
}
