package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.data.entities.Application;
import com.swyft.playarea.bankaccount.data.entities.ApplicationRequirementConsent;
import com.swyft.playarea.bankaccount.data.entities.Requirement;
import com.swyft.playarea.bankaccount.data.repository.ApplicationRepository;
import com.swyft.playarea.bankaccount.data.repository.ApplicationRequirementConsentRepository;
import com.swyft.playarea.bankaccount.data.repository.RequirementRepository;
import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.service.dto.ProductRequirementDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ApplicationRequirementService {

    private final ApplicationRepository applicationRepository;
    private final RequirementRepository requirementRepository;
    private final ApplicationRequirementConsentRepository consentRepository;
    private final ProductService productService;
    private final DocumentService documentService;

    /**
     * Verifies that all requirements for an application have been met
     * This includes:
     * 1. All mandatory consents have been given
     * 2. All required documents have been uploaded and verified
     *
     * @param applicationId the application ID
     * @return true if all requirements are met, false otherwise
     */
    @Transactional(readOnly = true)
    public boolean areAllRequirementsMet(String applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new PlatformException("Application not found"));

        // Check if all required consents have been given
        boolean consentsMet = areAllRequiredConsentsMet(applicationId, application.getProductId());

        // Check if all required documents have been uploaded and verified
        boolean documentsMet = documentService.areAllRequiredDocumentsUploaded(applicationId, application.getProductId())
                && documentService.areAllDocumentsVerified(applicationId);

        return consentsMet && documentsMet;
    }

    /**
     * Checks if all required consents have been given for the application
     */
    private boolean areAllRequiredConsentsMet(String applicationId, String productId) {
        // Get all requirements for this product that need consent
        List<ProductRequirementDTO> productRequirements = productService.getCombinedRequirementsForProduct(productId);

        // Get requirement IDs that need consent and are mandatory
        List<String> mandatoryConsentRequirementIds = productRequirements.stream()
                .filter(ProductRequirementDTO::getIsMandatory)
                .map(ProductRequirementDTO::getRequirementId)
                .filter(reqId -> requirementRepository.findById(reqId)
                        .map(Requirement::getNeedsConsent)
                        .orElse(false))
                .toList();

        if (mandatoryConsentRequirementIds.isEmpty()) {
            return true; // No mandatory consents needed
        }

        // Get all consents for this application
        List<ApplicationRequirementConsent> givenConsents = consentRepository.findByApplicationId(applicationId);

        // Create a map of requirement ID to consent status
        Map<String, Boolean> consentMap = givenConsents.stream()
                .collect(Collectors.toMap(
                        ApplicationRequirementConsent::getRequirementId,
                        ApplicationRequirementConsent::getConsentGiven
                ));

        // Check if all mandatory consents have been given
        return mandatoryConsentRequirementIds.stream()
                .allMatch(reqId -> consentMap.getOrDefault(reqId, false));
    }
}
