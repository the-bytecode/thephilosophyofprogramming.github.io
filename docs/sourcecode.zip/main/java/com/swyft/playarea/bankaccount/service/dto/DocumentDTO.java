package com.swyft.playarea.bankaccount.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentDTO {
    
    private String id;
    private String documentTypeId;
    private String applicationId;
    private String acceptedDocumentId;
    private String originalFileName;
    private String storedFileName;
    private String filePath;
    private Long fileSize;
    private String contentType;
    private LocalDateTime uploadedDate;
    private Boolean isVerified;
    private String verifiedBy;
    private LocalDateTime verifiedDate;
    private String verificationComment;
    
    // Additional fields for UI display
    private String documentTypeName;
    private String acceptedDocumentName;
}
