package com.swyft.playarea.bankaccount.data.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@Table(name = "document", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Document extends BaseEntity {
    
    @Column(name = "application_id", nullable = false, length = 36)
    private String applicationId;
    
    @Column(name = "document_type_id", nullable = false, length = 36)
    private String documentTypeId;
    
    @Column(name = "accepted_document_id", nullable = false, length = 36)
    private String acceptedDocumentId;
    
    @Column(name = "original_file_name", nullable = false)
    private String originalFileName;
    
    @Column(name = "stored_file_name", nullable = false)
    private String storedFileName;
    
    @Column(name = "file_path", nullable = false, length = 500)
    private String filePath;
    
    @Column(name = "file_size", nullable = false)
    private Long fileSize;
    
    @Column(name = "content_type", nullable = false, length = 100)
    private String contentType;
    
    @Column(name = "uploaded_date", nullable = false)
    private LocalDateTime uploadedDate;
    
    @Column(name = "is_verified")
    private Boolean isVerified = Boolean.FALSE;
    
    @Column(name = "verified_by", length = 100)
    private String verifiedBy;
    
    @Column(name = "verified_date")
    private LocalDateTime verifiedDate;
    
    @Column(name = "verification_comment", columnDefinition = "TEXT")
    private String verificationComment;
}
