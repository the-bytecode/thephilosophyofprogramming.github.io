package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.PlatformException;

import com.swyft.playarea.bankaccount.controller.model.ApplicationRequest;
import com.swyft.playarea.bankaccount.controller.model.ApplicationResponse;
import com.swyft.playarea.bankaccount.controller.model.CustomerDetails;
import com.swyft.playarea.bankaccount.data.entities.ApplicationRequirementConsent;
import com.swyft.playarea.bankaccount.data.entities.Requirement;
import com.swyft.playarea.bankaccount.data.repository.ApplicationRepository;
import com.swyft.playarea.bankaccount.data.entities.Application;
import com.swyft.playarea.bankaccount.data.repository.ApplicationRequirementConsentRepository;
import com.swyft.playarea.bankaccount.data.repository.RequirementRepository;
import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import com.swyft.playarea.bankaccount.service.dto.*;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ApplicationService {

    private ApplicationRepository applicationRepository;
    private final ApplicationRequirementConsentRepository applicationRequirementConsentRepository;
    private final RequirementRepository requirementRepository;
    private final CustomerService customerService;
    private final ProductService productService;
    private final ApplicationHistoryService applicationHistoryService;

    @Transactional(readOnly = true)
    public List<ApplicationDTO> findApplicationsByCustomerAndProduct(String customerId, String productId) {
        return applicationRepository.findByCustomerIdAndProductId(
                        customerId,
                        productId
                ).stream()
                .map(this::toApplicationDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ApplicationDTO> findApplicationsByCustomerId(String customerId) {
        return applicationRepository.findAll().stream()
                .filter(app -> app.getCustomerId().equals(customerId))
                .map(this::toApplicationDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public ApplicationResponse createApplication(final ApplicationRequest applicationRequest,
                                                 String ipAddress, String userAgent) {


        // Perform validation on the incoming application data
        validateCustomerDetails(applicationRequest.getCustomerDetails());

        validateProductRequested(applicationRequest);

        // if all looks good, persist application request to the database
        String id = createUniqueApplicationId();
        Application application = processNewApplicationRequest(applicationRequest, id, ipAddress, userAgent);

        return buildResponse(application);
    }

    private void validateProductRequested(ApplicationRequest applicationRequest) {
        if (applicationRequest.getProductId() == null || applicationRequest.getProductId().trim().isEmpty()) {
            throw new PlatformException("Product ID is required");
        }

        boolean productActive = productService.isProductActive(applicationRequest.getProductId());

        if (!productActive) {
            throw new PlatformException("Product is not active");
        }
    }

    private void validateCustomerDetails(CustomerDetails customerDetails) {
        if (customerDetails == null) {
            throw new PlatformException("Customer details cannot be null");
        }
        customerDetails.validate();
    }

    private ApplicationResponse buildResponse(Application application) {
        return ApplicationResponse.builder()
                .applicationId(application.getId())
                .applicationNumber(application.getApplicationNumber())
                .productId(application.getProductId())
                .status(application.getStatus())
                .createdOn(application.getCreatedAt())
                .build();
    }

    private Application processNewApplicationRequest(ApplicationRequest applicationRequest, String id,
                                                     String ipAddress, String userAgent) {
        LocalDateTime now = LocalDateTime.now();

        // Find out if the user exists, if so get the user or create a new one.
        CustomerDTO customerDTO = fetchUserIfExistsOrCreateNew(applicationRequest);

        List<Application> byUserIdAndAccountTypeAndStatusIn = applicationRepository.findByCustomerIdAndProductIdAndStatusIn(
                customerDTO.getId(),
                applicationRequest.getProductId(),
                ApplicationStatus.getStatusesToCheckDuplication()
        );

        if (!byUserIdAndAccountTypeAndStatusIn.isEmpty()) {
            throw new PlatformException("Application already exists");
        }
        validateMandatoryConsents(applicationRequest.getProductId(), applicationRequest.getRequirementConsents());


        Application savedApplication = saveApplication(applicationRequest, id, customerDTO, now);

        saveRequirementConsents(savedApplication.getId(),
                applicationRequest.getRequirementConsents(), ipAddress, userAgent);

        applicationHistoryService.createHistoryEntry(
                savedApplication.getId(), null,
                ApplicationStatus.SUBMITTED,
                customerDTO.getId(), "Application submitted");


        return savedApplication;
    }

    private Application saveApplication(ApplicationRequest applicationRequest, String id, CustomerDTO customerDTO, LocalDateTime now) {
        Application application = Application.builder()
                .status(ApplicationStatus.SUBMITTED)
                .customerId(customerDTO.getId())
                .submittedDate(now)
                .createdAt(now)
                .updatedAt(now)
                .productId(applicationRequest.getProductId())
                .applicationNumber(generateApplicationNumber())
                .id(id)
                .build();

        Application savedApplication = applicationRepository.save(application);
        return savedApplication;
    }

    /**
     * Saves the requirement consents for an application
     */
    private void saveRequirementConsents(String applicationId, List<RequirementConsentDTO> consents,
                                         String ipAddress, String userAgent) {

        if (CollectionUtils.isEmpty(consents)) {
            return;
        }

        LocalDateTime now = LocalDateTime.now();

        for (RequirementConsentDTO consent : consents) {
            saveConsent(applicationId, ipAddress, userAgent, consent, now);
        }
    }

    private void saveConsent(String applicationId, String ipAddress, String userAgent, RequirementConsentDTO consent, LocalDateTime now) {
        ApplicationRequirementConsent consentEntity = new ApplicationRequirementConsent();
        consentEntity.setApplicationId(applicationId);
        consentEntity.setRequirementId(consent.getRequirementId());
        consentEntity.setConsentGiven(consent.getConsentGiven());
        consentEntity.setConsentDate(now);
        consentEntity.setIpAddress(ipAddress);
        consentEntity.setUserAgent(userAgent);

        applicationRequirementConsentRepository.save(consentEntity);
    }

    /**
     * Validates that all mandatory consent requirements have been provided
     */
    private void validateMandatoryConsents(String productId, List<RequirementConsentDTO> providedConsents) {
        // Get all requirements for the product
        List<ProductRequirementDTO> productRequirements = productService.getCombinedRequirementsForProduct(productId);

        // Filter to get only mandatory requirements that need consent
        List<String> mandatoryConsentRequirementIds = productRequirements.stream()
                .filter(ProductRequirementDTO::getIsMandatory)
                .map(ProductRequirementDTO::getRequirementId)
                .filter(reqId -> {
                    // Get requirement entity to check if it needs consent
                    return requirementRepository.findById(reqId)
                            .map(Requirement::getNeedsConsent)
                            .orElse(false);
                })
                .toList();

        if (mandatoryConsentRequirementIds.isEmpty()) {
            return; // No mandatory consent requirements
        }

        // If no consents provided at all
        if (providedConsents == null || providedConsents.isEmpty()) {
            throw new PlatformException("Missing required consents for application");
        }

        // Check each mandatory consent requirement
        for (String requiredConsentId : mandatoryConsentRequirementIds) {
            boolean consentFound = providedConsents.stream()
                    .anyMatch(consent -> consent.getRequirementId().equals(requiredConsentId) && consent.getConsentGiven());

            if (!consentFound) {
                String requirementName = requirementRepository.findById(requiredConsentId)
                        .map(Requirement::getName)
                        .orElse("Unknown");
                throw new PlatformException("Missing required consent: " + requirementName);
            }
        }
    }

    private CustomerDTO fetchUserIfExistsOrCreateNew(ApplicationRequest applicationRequest) {
        // Validate customer details
        CustomerDetails customerDetails = applicationRequest.getCustomerDetails();

        // Check if customer exists by SSN
        Optional<CustomerDTO> optionalCustomerDTO = customerService
                .findUserBySSN(customerDetails.getSsn());

        // If found, return existing customer or create a new one
        return optionalCustomerDTO.orElseGet(() -> customerService.createCustomer(customerDetails));

    }

    private String createUniqueApplicationId() {
        return UUID.randomUUID().toString();
    }

    public ApplicationDTO getApplicationById(String applicationId) {

        // 1. Get application by invoking repository
        Application application = getApplicationEntityOrThrowException(applicationId);

        // 2.  Convert application to Application DTO
        return toApplicationDTO(application);
    }

    // CRUD methods on application
    public ApplicationDataDTO getCompleteApplicationDataByApplicationId(String applicationId) {

        // 1. First get the application
        ApplicationDTO applicationDTO = getApplicationById(applicationId);

        // 2. Take user id from application entity and invoke user service to  get User dto
        CustomerDTO customerDTO = getUserByApplication(applicationDTO);

        // 3. Merge both user dto and application dto into ApplicationDataDTO
        return ApplicationDataDTO.builder()
                .customer(customerDTO)
                .application(applicationDTO)
                .build();

    }

    private ApplicationDTO toApplicationDTO(Application application) {
        return ApplicationDTO.builder()
                .id(application.getId())
                .accountType(application.getProductId())
                .status(application.getStatus())
                .createdAt(application.getCreatedAt())
                .updatedAt(application.getUpdatedAt())
                .userId(application.getCustomerId())
                .build();
    }

    private Application getApplicationEntityOrThrowException(String applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() -> new PlatformException("Application not found"));
    }

    private CustomerDTO getUserByApplication(ApplicationDTO application) {
        String userId = application.getUserId();
        return customerService.getUserById(userId);
    }

    @Transactional
    public ApplicationResponse updateApplication(String applicationId, ApplicationRequest applicationRequest) {
        // Find the existing application
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new PlatformException("Application not found with id: " + applicationId));

        // Validate that the application is in a state that can be updated
        if (application.getStatus() != ApplicationStatus.DRAFT) {
            throw new PlatformException("Application cannot be updated in its current state: " + application.getStatus());
        }

        // Update customer information if needed
        customerService.updateCustomer(
                application.getCustomerId(),
                applicationRequest.getCustomerDetails()
        );

        // Update application fields
        LocalDateTime now = LocalDateTime.now();
        application.setUpdatedAt(now);

        // If product type changed
        if (!application.getProductId().equals(applicationRequest.getProductId())) {
            // throw exception if product type changed
            if (!ApplicationStatus.isInProgress(application.getStatus())) {
                throw new PlatformException("Product type cannot be changed in its current state: " + application.getStatus());
            } else {
                application.setProductId(applicationRequest.getProductId());
            }
        }

        // Save the updated application
        Application updatedApplication = applicationRepository.save(application);

        // Build and return the response
        return ApplicationResponse.builder()
                .applicationId(updatedApplication.getId())
                .productId(updatedApplication.getProductId())
                .status(updatedApplication.getStatus())
                .createdOn(updatedApplication.getCreatedAt())
                .build();
    }

    /**
     * Generate a unique application number with a readable format.
     * Format: APP-YYMMDDxxxxxxxx (where x is a random alphanumeric character)
     *
     * @return a uniquely generated application number
     */
    private String generateApplicationNumber() {
        LocalDateTime now = LocalDateTime.now();
        String datePart = now.format(DateTimeFormatter.ofPattern("yyMMdd"));

        // Generate a random 8-character alphanumeric string
        String randomPart = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8).toUpperCase();

        return "APP-" + datePart + randomPart;
    }

    public void deleteApplication(String applicationId) {
        applicationRepository.deleteById(applicationId);
    }

    // find all
    public Iterable<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    // count
    public long countApplications() {
        return applicationRepository.count();
    }

    // delete all
    public void deleteAllApplications() {
        applicationRepository.deleteAll();
    }

    // exists
    public boolean existsApplication(String applicationId) {
        return applicationRepository.existsById(applicationId);
    }
}
