package com.swyft.playarea.bankaccount.controller.model;

import com.swyft.playarea.bankaccount.service.dto.RequirementConsentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class ApplicationRequest {

    private String productId;
    private CustomerDetails customerDetails;
    private List<RequirementConsentDTO> requirementConsents;
}
