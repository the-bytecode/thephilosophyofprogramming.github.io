package com.swyft.playarea.bankaccount.data.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "requirement_document_type", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RequirementDocumentType extends BaseEntity {

    @Column(name = "requirement_id", nullable = false, length = 36)
    private String requirementId;

    @Column(name = "document_type_id", nullable = false, length = 36)
    private String documentTypeId;

    @Column(name = "is_mandatory")
    private Boolean isMandatory = Boolean.TRUE;
}