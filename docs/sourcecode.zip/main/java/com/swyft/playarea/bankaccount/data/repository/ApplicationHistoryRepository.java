package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.ApplicationHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationHistoryRepository extends JpaRepository<ApplicationHistory, String> {
    
    List<ApplicationHistory> findByApplicationIdOrderByChangedDateDesc(String applicationId);
}
