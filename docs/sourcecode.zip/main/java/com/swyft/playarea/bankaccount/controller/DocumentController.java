package com.swyft.playarea.bankaccount.controller;


import com.swyft.playarea.bankaccount.controller.model.DocumentUploadRequest;
import com.swyft.playarea.bankaccount.service.DocumentService;
import com.swyft.playarea.bankaccount.service.dto.AcceptedDocumentDTO;
import com.swyft.playarea.bankaccount.service.dto.DocumentDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Documents", description = "API endpoints for managing application documents")
public class DocumentController {

    private final DocumentService documentService;

    @Operation(summary = "Get documents by application", description = "Retrieves all documents uploaded for a specific application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Documents retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = DocumentDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Application not found")
    })
    @GetMapping("/application/{applicationId}/documents")
    public List<DocumentDTO> getDocumentsByApplication(@PathVariable String applicationId) {
        return documentService.getDocumentsByApplicationId(applicationId);
    }

    @Operation(summary = "Get accepted documents by type", description = "Retrieves all accepted document types for a specific document category")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Accepted documents retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AcceptedDocumentDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Document type not found")
    })
    @GetMapping("/documents/{documentTypeId}/accepted-documents")
    public List<AcceptedDocumentDTO> getAcceptedDocumentsByType(@PathVariable String documentTypeId) {
        return documentService.getAcceptedDocumentsByDocumentTypeId(documentTypeId);
    }

    @Operation(summary = "Upload document", description = "Uploads a document for a specific application")

    @PostMapping(value = "/application/{applicationId}/documents",  consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public DocumentDTO uploadDocument(
            @PathVariable String applicationId,
            @RequestPart("file") MultipartFile file,
            @RequestPart("documentInfo") DocumentUploadRequest documentUploadRequest) {
        return documentService.uploadDocument(applicationId, file, documentUploadRequest);
    }

    @Operation(summary = "Verify document", description = "Marks a document as verified or rejected")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Document verification status updated",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = DocumentDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Document not found")
    })
    @PatchMapping("/{documentId}/verifications")
    public DocumentDTO verifyDocument(
            @PathVariable String documentId,
            @RequestParam String verifiedBy,
            @RequestParam String verificationComment,
            @RequestParam Boolean isVerified) {
        return documentService.verifyDocument(documentId, verifiedBy, verificationComment, isVerified);
    }
}
