package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.data.entities.Application;

import com.swyft.playarea.bankaccount.data.repository.ApplicationRepository;
import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import com.swyft.playarea.bankaccount.service.dto.ApplicationStatusUpdateDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ApplicationStatusService {

    private final ApplicationRepository applicationRepository;
    private final ApplicationRequirementService applicationRequirementService;
    private final ApplicationHistoryService applicationHistoryService;

    // Define allowed status transitions
    private static final Map<ApplicationStatus, Set<ApplicationStatus>> ALLOWED_TRANSITIONS = Map.of(
            ApplicationStatus.DRAFT, Set.of(ApplicationStatus.SUBMITTED, ApplicationStatus.CANCELLED),
            ApplicationStatus.SUBMITTED, Set.of(ApplicationStatus.UNDER_REVIEW, ApplicationStatus.PENDING_DOCUMENTS, ApplicationStatus.PENDING_KYC, ApplicationStatus.CANCELLED),
            ApplicationStatus.UNDER_REVIEW, Set.of(ApplicationStatus.APPROVED, ApplicationStatus.REJECTED, ApplicationStatus.PENDING_DOCUMENTS, ApplicationStatus.PENDING_KYC),
            ApplicationStatus.PENDING_DOCUMENTS, Set.of(ApplicationStatus.UNDER_REVIEW, ApplicationStatus.CANCELLED),
            ApplicationStatus.PENDING_KYC, Set.of(ApplicationStatus.UNDER_REVIEW, ApplicationStatus.CANCELLED),
            ApplicationStatus.APPROVED, Set.of(),
            ApplicationStatus.REJECTED, Set.of(),
            ApplicationStatus.CANCELLED, Set.of()
    );

    @Transactional
    public void updateApplicationStatus(String applicationId, ApplicationStatusUpdateDTO statusUpdateDTO) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new PlatformException("Application not found with id: " + applicationId));

        ApplicationStatus currentStatus = application.getStatus();
        ApplicationStatus newStatus = ApplicationStatus.valueOf(statusUpdateDTO.getNewStatus());

        // Validate status transition
        if (!isValidStatusTransition(currentStatus, newStatus)) {
            throw new PlatformException("Invalid status transition from " + currentStatus + " to " + newStatus);
        }

        // If transitioning to APPROVED, check if all requirements are met
        if (newStatus == ApplicationStatus.APPROVED) {
            boolean allRequirementsMet = applicationRequirementService.areAllRequirementsMet(applicationId);
            if (!allRequirementsMet) {
                throw new PlatformException("Cannot approve application: Not all requirements have been met");
            }
        }

        LocalDateTime now = LocalDateTime.now();

        applicationHistoryService.
                createHistoryEntryFromStatusUpdate(applicationId, currentStatus, newStatus, statusUpdateDTO);

        // Update application status
        application.setStatus(newStatus);
        application.setUpdatedAt(now);

        // If status is being reviewed, update review information
        if (newStatus == ApplicationStatus.UNDER_REVIEW ||
                newStatus == ApplicationStatus.APPROVED ||
                newStatus == ApplicationStatus.REJECTED) {
            application.setReviewedBy(statusUpdateDTO.getChangedBy());
            application.setReviewedDate(now);
            application.setReviewComments(statusUpdateDTO.getComments());
        }

        // Save changes
        applicationHistoryService.
                createHistoryEntryFromStatusUpdate(applicationId, currentStatus, newStatus, statusUpdateDTO);
        applicationRepository.save(application);

//         Publish event for status change
//         eventPublisher.publishEvent(new ApplicationStatusChangedEvent(application, currentStatus, newStatus));
    }

    private boolean isValidStatusTransition(ApplicationStatus currentStatus, ApplicationStatus newStatus) {
        // Get allowed next statuses for the current status
        Set<ApplicationStatus> allowedNextStatuses = ALLOWED_TRANSITIONS.get(currentStatus);

        // Check if the new status is allowed
        return allowedNextStatuses != null && allowedNextStatuses.contains(newStatus);
    }
}
