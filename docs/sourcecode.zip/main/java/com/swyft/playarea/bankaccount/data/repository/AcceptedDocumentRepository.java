package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.AcceptedDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AcceptedDocumentRepository extends JpaRepository<AcceptedDocument, String> {

    Optional<AcceptedDocument> findByCode(String code);

    List<AcceptedDocument> findByIsActiveTrue();

    @Query("SELECT ad FROM AcceptedDocument ad " +
            "JOIN DocumentTypeAcceptedDocument dtad ON ad.id = dtad.acceptedDocumentId " +
            "WHERE dtad.documentTypeId = :documentTypeId AND ad.isActive = true")
    List<AcceptedDocument> findByDocumentTypeId(@Param("documentTypeId") String documentTypeId);

}
