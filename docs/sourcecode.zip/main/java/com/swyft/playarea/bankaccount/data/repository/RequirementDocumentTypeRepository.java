package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.RequirementDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RequirementDocumentTypeRepository extends JpaRepository<RequirementDocumentType, String> {
    
    List<RequirementDocumentType> findByRequirementId(String requirementId);
    
    List<RequirementDocumentType> findByRequirementIdAndIsMandatory(String requirementId, Boolean isMandatory);
    
    List<RequirementDocumentType> findByDocumentTypeId(String documentTypeId);
}
