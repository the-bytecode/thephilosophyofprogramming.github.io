package com.swyft.playarea.bankaccount.controller;


import com.swyft.playarea.bankaccount.service.RequirementService;
import com.swyft.playarea.bankaccount.service.dto.DocumentTypeDTO;
import com.swyft.playarea.bankaccount.service.dto.RequirementDTO;
import com.swyft.playarea.bankaccount.service.dto.RequirementDocumentTypeDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/requirements")
@RequiredArgsConstructor
@Tag(name = "Requirements", description = "API endpoints for managing product requirements")
public class RequirementController {

    private final RequirementService requirementService;

    @Operation(summary = "Get all requirements", description = "Retrieves all available requirements")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Requirements retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = RequirementDTO.class, type = "array"))})
    })
    @GetMapping
    public List<RequirementDTO> getAllRequirements() {
        return requirementService.getAllRequirements();
    }

    @Operation(summary = "Get requirement by code", description = "Retrieves a requirement by its unique code")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Requirement found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = RequirementDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Requirement not found")
    })
    @GetMapping("/code/{code}")
    public RequirementDTO getRequirementByCode(@PathVariable String code) {
        return requirementService.getRequirementByCode(code);
    }

    @Operation(summary = "Get document types by requirement", description = "Retrieves all document types associated with a requirement")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Document types retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = DocumentTypeDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Requirement not found")
    })
    @GetMapping("/{requirementId}/documents")
    public List<DocumentTypeDTO> getDocumentTypesByRequirement(@PathVariable String requirementId) {
        return requirementService.getDocumentTypesByRequirementId(requirementId);
    }

    @Operation(summary = "Get requirement document types", description = "Retrieves requirement-document type mappings")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Requirement document types retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = RequirementDocumentTypeDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Requirement not found")
    })
    @GetMapping("/{requirementId}")
    public List<RequirementDocumentTypeDTO> getRequirementDocumentTypes(@PathVariable String requirementId) {
        return requirementService.getRequirementDocumentTypes(requirementId);
    }
}
