package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.DocumentTypeAcceptedDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentTypeAcceptedDocumentRepository extends JpaRepository<DocumentTypeAcceptedDocument, String> {
    List<DocumentTypeAcceptedDocument> findByDocumentTypeId(String documentTypeId);
}