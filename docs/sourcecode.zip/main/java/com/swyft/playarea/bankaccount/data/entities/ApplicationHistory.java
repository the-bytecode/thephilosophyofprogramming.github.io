package com.swyft.playarea.bankaccount.data.entities;

import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "application_history", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationHistory extends BaseEntity {
    
    @Column(name = "application_id", nullable = false, length = 36)
    private String applicationId;
    
    @Column(name = "previous_status", length = 36)
    @Enumerated(EnumType.STRING)
    private ApplicationStatus previousStatus;
    
    @Column(name = "new_status", nullable = false, length = 36)
    @Enumerated(EnumType.STRING)
    private ApplicationStatus newStatus;
    
    @Column(name = "changed_by", length = 100)
    private String changedBy;
    
    @Column(name = "changed_date", nullable = false)
    private LocalDateTime changedDate;
    
    @Column(name = "comments", columnDefinition = "TEXT")
    private String comments;
}
