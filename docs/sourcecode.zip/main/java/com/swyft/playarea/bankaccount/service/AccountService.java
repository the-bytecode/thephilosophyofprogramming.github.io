package com.swyft.playarea.bankaccount.service;


import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.data.repository.ApplicationRepository;
import com.swyft.playarea.bankaccount.data.entities.Account;
import com.swyft.playarea.bankaccount.data.entities.Application;

import com.swyft.playarea.bankaccount.data.repository.AccountRepository;
import com.swyft.playarea.bankaccount.enums.AccountStatus;
import com.swyft.playarea.bankaccount.enums.ApplicationStatus;

import com.swyft.playarea.bankaccount.service.dto.AccountDTO;
import com.swyft.playarea.bankaccount.service.mapper.AccountMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepository accountRepository;
    private final ApplicationRepository applicationRepository;
    private final AccountMapper accountMapper;
    private final DocumentService documentService;


    @Transactional(readOnly = true)
    public List<AccountDTO> getAccountsByCustomerId(String customerId) {
        List<Account> accounts = accountRepository.findByCustomerId(customerId);
        return accounts.stream()
                .map(accountMapper::toDto)
                .collect(Collectors.toList());
    }


    @Transactional(readOnly = true)
    public AccountDTO getAccountById(String id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new PlatformException("Account not found with id: " + id));

        return accountMapper.toDto(account);
    }


    @Transactional(readOnly = true)
    public AccountDTO getAccountByAccountNumber(String accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new PlatformException("Account not found with number: " + accountNumber));

        return accountMapper.toDto(account);
    }

    @Transactional
    public AccountDTO createAccountFromApplication(String applicationId) {
        // Find application
        Application application = getApplicationOrThrowException(applicationId);

        preCheck(applicationId, application);

        // Generate account number
        String accountNumber = generateAccountNumber();

        // Create new account
        Account account = buildAccountEntity(application, accountNumber);

        Account savedAccount = accountRepository.save(account);
        return accountMapper.toDto(savedAccount);
    }

    private Application getApplicationOrThrowException(String applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() -> new PlatformException("Application not found with id: " + applicationId));
    }

    private static Account buildAccountEntity(Application application, String accountNumber) {
        return Account.builder()
                .customerId(application.getCustomerId())
                .productId(application.getProductId())
                .applicationId(application.getId())
                .accountNumber(accountNumber)
                .status(AccountStatus.ACTIVE)
                .openedDate(LocalDateTime.now())
                .build();
    }

    private void preCheck(String applicationId, Application application) {
        // Verify application is approved
        if (application.getStatus() != ApplicationStatus.APPROVED) {
            throw new PlatformException("Cannot create account: Application is not approved");
        }

        // Check if account already exists for this application
        List<Account> existingAccounts = accountRepository.findByApplicationId(applicationId);
        if (!existingAccounts.isEmpty()) {
            throw new PlatformException("Account already exists for this application");
        }

        // Verify all mandatory documents are uploaded and verified
        String productId = application.getProductId();
        if (!documentService.areAllRequiredDocumentsUploaded(applicationId, productId)) {
            throw new PlatformException("Cannot create account: Not all required documents are uploaded");
        }

        if (!documentService.areAllDocumentsVerified(applicationId)) {
            throw new PlatformException("Cannot create account: Not all documents are verified");
        }
    }

    @Transactional
    public AccountDTO closeAccount(String accountId, String closureReason) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new PlatformException("Account not found with id: " + accountId));

        account.setStatus(AccountStatus.CLOSED);
        account.setClosedDate(LocalDateTime.now());
        account.setClosureReason(closureReason);

        Account closedAccount = accountRepository.save(account);
        return accountMapper.toDto(closedAccount);
    }

    private String generateAccountNumber() {
        return "ACC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
