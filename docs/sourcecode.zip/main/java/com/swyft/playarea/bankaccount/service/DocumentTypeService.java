package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.data.repository.DocumentTypeRepository;
import com.swyft.playarea.bankaccount.service.dto.DocumentTypeDTO;
import com.swyft.playarea.bankaccount.service.mapper.DocumentTypeMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class DocumentTypeService {

    private final DocumentTypeRepository documentTypeRepository;
    private final DocumentTypeMapper documentTypeMapper;


    /**
     * Find a DocumentType by its ID
     *
     * @param id The document type ID
     * @return Optional containing the DTO if found
     */
    @Transactional(readOnly = true)
    public Optional<DocumentTypeDTO> findById(String id) {
        return documentTypeRepository.findById(id)
                .map(documentTypeMapper::toDTO);
    }

    /**
     * Find a DocumentType by its code
     *
     * @param code The document type code
     * @return Optional containing the DTO if found
     */
    @Transactional(readOnly = true)
    public Optional<DocumentTypeDTO> findByCode(String code) {
        return documentTypeRepository.findByCode(code)
                .map(documentTypeMapper::toDTO);
    }

    /**
     * Find all DocumentTypes associated with a specific product
     *
     * @param productId The product ID
     * @return List of document type DTOs
     */
    @Transactional(readOnly = true)
    public List<DocumentTypeDTO> findByProductId(String productId) {
        return documentTypeRepository.findByProductId(productId).stream()
                .map(documentTypeMapper::toDTO)
                .collect(Collectors.toList());
    }

    /**
     * Find all DocumentTypes associated with a specific requirement
     *
     * @param requirementId The requirement ID
     * @return List of document type DTOs
     */
    @Transactional(readOnly = true)
    public List<DocumentTypeDTO> findByRequirementId(String requirementId) {
        return documentTypeRepository.findByRequirementId(requirementId).stream()
                .map(documentTypeMapper::toDTO)
                .collect(Collectors.toList());
    }
}