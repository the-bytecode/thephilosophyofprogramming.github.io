package com.swyft.playarea.bankaccount.service.dto;

import com.swyft.playarea.bankaccount.service.dto.AcceptedDocumentDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RequirementDocumentTypeDTO {
    
    private String id;
    private String requirementId;
    private String requirementName;
    private String requirementDescription;
    private String requirementCode;
    private String documentTypeId;
    private String documentTypeName;
    private String documentTypeDescription;
    private String documentTypeCode;
    private Boolean isMandatory;
    
    // For nested responses
    private List<AcceptedDocumentDTO> acceptedDocuments;
}
