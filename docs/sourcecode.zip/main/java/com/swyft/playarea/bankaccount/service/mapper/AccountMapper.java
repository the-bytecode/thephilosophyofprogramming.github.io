package com.swyft.playarea.bankaccount.service.mapper;

import com.swyft.playarea.bankaccount.data.entities.Account;
import com.swyft.playarea.bankaccount.service.CustomerService;
import com.swyft.playarea.bankaccount.service.ProductService;
import com.swyft.playarea.bankaccount.service.dto.AccountDTO;
import com.swyft.playarea.bankaccount.service.dto.CustomerDTO;
import com.swyft.playarea.bankaccount.service.dto.ProductDTO;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class AccountMapper {
    private final CustomerService customerService;
    private final ProductService productService;

    public AccountDTO toDto(Account account) {
        return AccountDTO.builder()
                .id(account.getId())
                .accountNumber(account.getAccountNumber())
                .status(account.getStatus())
                .openedDate(account.getOpenedDate())
                .closedDate(account.getClosedDate())
                .closureReason(account.getClosureReason())
                .productId(account.getProductId())
                .applicationId(account.getApplicationId())
                .customerId(account.getCustomerId())
                .productName(getProductName(account.getProductId()))
                .customerName(getCustomerName(account.getCustomerId()))
                .build();
    }

    private String getCustomerName(String customerId) {
        CustomerDTO customerDTO = customerService.findCustomerById(customerId);

        if (customerDTO == null) {
            return StringUtils.EMPTY;
        }
        // validate emptiness using string utils blank
        if (StringUtils.isBlank(customerDTO.getFirstname()) && StringUtils.isBlank(customerDTO.getLastname())) {
            return StringUtils.EMPTY;
        }
        if (StringUtils.isBlank(customerDTO.getFirstname())) {
            return customerDTO.getLastname();
        }
        if (StringUtils.isBlank(customerDTO.getLastname())) {
            return customerDTO.getFirstname();
        }

        return customerDTO.getFirstname() + StringUtils.EMPTY + customerDTO.getLastname();
    }

    private String getProductName(String productId) {
        ProductDTO productDTO = productService.getProductById(productId);

        return productDTO.getName();
    }
}
