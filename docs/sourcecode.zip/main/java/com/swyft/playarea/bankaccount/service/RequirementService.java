package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.data.entities.*;

import com.swyft.playarea.bankaccount.data.repository.*;
import com.swyft.playarea.bankaccount.service.dto.DocumentTypeDTO;
import com.swyft.playarea.bankaccount.service.dto.ProductRequirementDTO;
import com.swyft.playarea.bankaccount.service.dto.RequirementDTO;
import com.swyft.playarea.bankaccount.service.dto.RequirementDocumentTypeDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RequirementService {
    
    private final RequirementRepository requirementRepository;
    private final ProductRequirementRepository productRequirementRepository;
    private final RequirementDocumentTypeRepository requirementDocumentTypeRepository;
    private final DocumentTypeRepository documentTypeRepository;
    private final ProductRepository productRepository;
    private final DocumentService documentService;
    
    @Transactional(readOnly = true)
    public List<ProductRequirementDTO> getRequirementsByProductId(String productId) {
        List<ProductRequirement> productRequirements = productRequirementRepository.findByProductId(productId);
        List<ProductRequirementDTO> result = new ArrayList<>();
        
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));
        
        for (ProductRequirement pr : productRequirements) {
            Requirement requirement = requirementRepository.findById(pr.getRequirementId())
                    .orElseThrow(() -> new PlatformException("Requirement not found with id: " + pr.getRequirementId()));
            
            ProductRequirementDTO dto = ProductRequirementDTO.builder()
                    .id(pr.getId())
                    .productId(productId)
                    .productName(product.getName())
                    .requirementId(requirement.getId())
                    .requirementName(requirement.getName())
                    .requirementDescription(requirement.getDescription())
                    .requirementCode(requirement.getCode())
                    .isMandatory(pr.getIsMandatory())
                    .build();
            
            result.add(dto);
        }
        
        return result;
    }
    
    @Transactional(readOnly = true)
    public List<DocumentTypeDTO> getDocumentTypesByRequirementId(String requirementId) {
        List<RequirementDocumentType> requirementDocumentTypes = requirementDocumentTypeRepository.findByRequirementId(requirementId);
        List<DocumentTypeDTO> result = new ArrayList<>();
        
        for (RequirementDocumentType rdt : requirementDocumentTypes) {
            DocumentType documentType = documentTypeRepository.findById(rdt.getDocumentTypeId())
                    .orElseThrow(() -> new PlatformException("Document type not found with id: " + rdt.getDocumentTypeId()));
            
            DocumentTypeDTO dto = DocumentTypeDTO.builder()
                    .id(documentType.getId())
                    .name(documentType.getName())
                    .description(documentType.getDescription())
                    .code(documentType.getCode())
                    .isMandatory(rdt.getIsMandatory())
                    .build();
            
            // Add accepted documents for this document type
            dto.setAcceptedDocuments(documentService.getAcceptedDocumentsByDocumentTypeId(documentType.getId()));
            
            result.add(dto);
        }
        
        return result;
    }
    
    @Transactional(readOnly = true)
    public List<RequirementDocumentTypeDTO> getRequirementDocumentTypes(String requirementId) {
        List<RequirementDocumentType> requirementDocumentTypes = requirementDocumentTypeRepository.findByRequirementId(requirementId);
        List<RequirementDocumentTypeDTO> result = new ArrayList<>();
        
        Requirement requirement = requirementRepository.findById(requirementId)
                .orElseThrow(() -> new PlatformException("Requirement not found with id: " + requirementId));
        
        for (RequirementDocumentType rdt : requirementDocumentTypes) {
            DocumentType documentType = documentTypeRepository.findById(rdt.getDocumentTypeId())
                    .orElseThrow(() -> new PlatformException("Document type not found with id: " + rdt.getDocumentTypeId()));
            
            RequirementDocumentTypeDTO dto = RequirementDocumentTypeDTO.builder()
                    .id(rdt.getId())
                    .requirementId(requirementId)
                    .requirementName(requirement.getName())
                    .requirementDescription(requirement.getDescription())
                    .requirementCode(requirement.getCode())
                    .requirementCode(requirement.getCode())
                    .documentTypeId(documentType.getId())
                    .documentTypeName(documentType.getName())
                    .documentTypeDescription(documentType.getDescription())
                    .documentTypeCode(documentType.getCode())
                    .isMandatory(rdt.getIsMandatory())
                    .build();
            
            // Add accepted documents for this document type
            dto.setAcceptedDocuments(documentService.getAcceptedDocumentsByDocumentTypeId(documentType.getId()));
            
            result.add(dto);
        }
        
        return result;
    }
    
    @Transactional(readOnly = true)
    public List<RequirementDTO> getAllRequirements() {
        List<Requirement> requirements = requirementRepository.findAll();
        return requirements.stream()
                .map(req -> {
                    RequirementDTO dto = RequirementDTO.builder()
                            .id(req.getId())
                            .name(req.getName())
                            .description(req.getDescription())
                            .code(req.getCode())
                            .needsConsent(req.getNeedsConsent())
                            .consentText(req.getConsentText())
                            .build();
                    
                    // Add document types for this requirement
                    dto.setDocumentTypes(getDocumentTypesByRequirementId(req.getId()));
                    
                    return dto;
                })
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public RequirementDTO getRequirementByCode(String code) {
        Requirement requirement = requirementRepository.findByCode(code)
                .orElseThrow(() -> new PlatformException("Requirement not found with code: " + code));
        
        RequirementDTO dto = RequirementDTO.builder()
                .id(requirement.getId())
                .name(requirement.getName())
                .description(requirement.getDescription())
                .code(requirement.getCode())
                .needsConsent(requirement.getNeedsConsent())
                .consentText(requirement.getConsentText())
                .build();
        
        // Add document types for this requirement
        dto.setDocumentTypes(getDocumentTypesByRequirementId(requirement.getId()));
        
        return dto;
    }
}
