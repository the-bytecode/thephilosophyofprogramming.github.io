package com.swyft.playarea.bankaccount.service.dto;

import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@Getter
public class ApplicationDTO {
    private String id;
    private String userId;
    private String accountType;
    private ApplicationStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}



