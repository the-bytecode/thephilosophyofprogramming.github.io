package com.swyft.playarea.bankaccount.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AcceptedDocumentDTO {
    
    private String id;
    private String name;
    private String description;
    private String code;
    private Boolean isActive;
}
