package com.swyft.playarea.bankaccount.service.dto;


import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductDTO {

    private String id;
    private String bankId;
    private String name;
    private String code;
    private String description;
    private String parentId;
    private Boolean isActive;
    
    // Additional fields for UI display
    private String bankName;
    private String parentName;
    private List<ProductDTO> subProducts;
    private List<RequirementDTO> requirements;
    private List<DocumentTypeDTO> documentTypes;
}
