package com.swyft.playarea.bankaccount.service.mapper;

import com.swyft.playarea.bankaccount.data.entities.DocumentType;
import com.swyft.playarea.bankaccount.service.dto.DocumentTypeDTO;
import org.springframework.stereotype.Component;

@Component
public class DocumentTypeMapper {
    public DocumentTypeDTO toDTO(DocumentType documentType) {
        return DocumentTypeDTO.builder()
                .id(documentType.getId())
                .name(documentType.getName())
                .description(documentType.getDescription())
                .build();
    }
}
