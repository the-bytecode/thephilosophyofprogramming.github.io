package com.swyft.playarea.bankaccount.service.mapper;

import com.swyft.playarea.bankaccount.data.entities.Bank;
import com.swyft.playarea.bankaccount.service.dto.BankDTO;
import org.springframework.stereotype.Component;

@Component
public class BankMapper {

    public BankDTO toDto(Bank bank) {
        return com.swyft.playarea.bankaccount.service.dto.BankDTO.builder()
                .id(bank.getId())
                .name(bank.getName())
                .code(bank.getCode())
                .establishedDate(bank.getEstablishedDate())
                .active(bank.getActive())
                .build();
    }
}
