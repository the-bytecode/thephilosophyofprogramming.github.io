package com.swyft.playarea.bankaccount.event;

import com.swyft.playarea.bankaccount.data.repository.ApplicationRepository;
import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import com.swyft.playarea.bankaccount.service.DocumentService;
import com.swyft.playarea.bankaccount.service.ApplicationStatusService;
import com.swyft.playarea.bankaccount.service.dto.ApplicationStatusUpdateDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
@Slf4j
public class ApplicationDocumentListener {

    private final DocumentService documentService;
    private final ApplicationRepository applicationRepository;
    private final ApplicationStatusService applicationStatusService;

    @EventListener
    @Transactional
    @Async
    public void handleDocumentVerifiedEvent(DocumentVerifiedEvent event) {
        String applicationId = event.getApplicationId();
        log.info("Document verified for application: {}, document: {}, verified: {}",
                applicationId, event.getDocumentId(), event.getIsVerified());

        // Get the application
        applicationRepository.findById(applicationId).ifPresent(application -> {
            // Check if application is in PENDING_DOCUMENTS status
            if (application.getStatus() == ApplicationStatus.PENDING_DOCUMENTS) {

                // Check if all required documents are verified
                String productId = application.getProductId();
                boolean allDocumentsVerified = documentService.areAllDocumentsVerified(applicationId);
                boolean allRequiredDocumentsUploaded = documentService.areAllRequiredDocumentsUploaded(applicationId, productId);

                // If all documents are verified and all required documents are uploaded,
                // transition to UNDER_REVIEW status
                if (allDocumentsVerified && allRequiredDocumentsUploaded) {
                    ApplicationStatusUpdateDTO statusUpdate = ApplicationStatusUpdateDTO.builder()
                            .newStatus(ApplicationStatus.UNDER_REVIEW.name())
                            .changedBy("SYSTEM")
                            .comments("All required documents have been verified")
                            .build();

                    applicationStatusService.updateApplicationStatus(applicationId, statusUpdate);
                    log.info("Application {} transitioned to UNDER_REVIEW status", applicationId);
                }
            }
        });
    }
}
