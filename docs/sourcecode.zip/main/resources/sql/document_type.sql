insert into bank_account.document_type (id, name, description, code, created_at, updated_at)
values  ('dt01b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Identity Proof', 'Documents proving identity', 'IDPROOF', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968'),
        ('dt02b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Address Proof', 'Documents proving current address', 'ADDRPROOF', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968'),
        ('dt03b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Income Proof', 'Documents proving income source', 'INCOMEPROOF', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968'),
        ('dt04b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Employment Proof', 'Documents proving employment status', 'EMPLOYPROOF', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968'),
        ('dt05b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Tax Documents', 'Tax-related documents', 'TAXDOCS', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968'),
        ('dt06b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Property Documents', 'Documents related to property', 'PROPDOCS', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968'),
        ('dt07b2c3-4d5e-6f7g-8h9i-j0k1l2m3n4o5', 'Vehicle Documents', 'Documents related to vehicle', 'VEHICLEDOCS', '2025-04-05 14:59:22.642968', '2025-04-05 14:59:22.642968');