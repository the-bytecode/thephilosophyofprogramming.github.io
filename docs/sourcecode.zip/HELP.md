# Bank Account Application Documentation

This document provides a comprehensive overview of the Bank Account Application system. The application allows customers to apply for bank accounts, upload required documents, and manage their account applications through various stages.

## Table of Contents
- [System Overview](#system-overview)
- [Database Schema](#database-schema)
    - [Entity Relationship Diagram](#entity-relationship-diagram)
    - [Tables and Relationships](#tables-and-relationships)
- [Application Flows](#application-flows)
    - [Account Application Flow](#account-application-flow)
    - [Document Management Flow](#document-management-flow)
    - [Application Status Flow](#application-status-flow)
    - [Account Creation Flow](#account-creation-flow)
- [API Endpoints](#api-endpoints)
    - [Account Applications](#account-applications)
    - [Accounts](#accounts)
    - [Banks and Products](#banks-and-products)
    - [Customers](#customers)
    - [Documents](#documents)
    - [Requirements](#requirements)
- [Best Practices and Implementation Notes](#best-practices-and-implementation-notes)

## System Overview

The Bank Account Application is a Java Spring Boot application that provides a comprehensive backend for managing bank account applications. The system allows customers to:

1. Browse available banks and banking products
2. Apply for bank accounts
3. Submit required documentation
4. Track application status
5. Manage their accounts once approved

The application is built with a multi-tier architecture:
- **Controller Layer**: Handles HTTP requests and responses
- **Service Layer**: Contains business logic
- **Repository Layer**: Interfaces with the database
- **Entity Layer**: Maps database tables to Java objects

## Database Schema

### Entity Relationship Diagram

```
                                          +-------------+
                                          |    Bank     |
                                          +-------------+
                                          |    id       |
                                          |    name     |
                                          |    code     |
                                          +-------------+
                                                 |
                                                 |
                                                 v
+-------------+     +--------------+     +-------------+     +-------------------+
|  Customer   |<--- | Application  |<--- |   Product   |<--- | ProductRequirement|
+-------------+     +--------------+     +-------------+     +-------------------+
|    id       |     |    id        |     |    id       |     |       id          |
|  firstName  |     | customerId   |     |  bankId     |     |    productId      |
|  lastName   |     | productId    |     |  name       |     |  requirementId    |
|    email    |     |  status      |     |  code       |     |   isMandatory     |
|    etc.     |     |    etc.      |     | parentId    |     +-------------------+
+-------------+     +--------------+     +-------------+             |
                           |                    |                    |
                           |                    |                    v
                           v                    v              +-------------+
                    +-------------+     +----------------+     | Requirement |
                    |   Account   |     | ProductDocType |     +-------------+
                    +-------------+     +----------------+     |     id      |
                    |     id      |     |      id        |     |    name     |
                    | customerId  |     |   productId    |     |    code     |
                    |  productId  |     | documentTypeId |     | description |
                    |    etc.     |     |  isMandatory   |     +-------------+
                    +-------------+     +----------------+            |
                                                |                     |
                                                v                     v
                    +-------------+     +----------------+     +------------------+
                    |  Document   |<--- | DocumentType   |<--- | ReqDocumentType  |
                    +-------------+     +----------------+     +------------------+
                    |     id      |     |      id        |     |        id        |
                    | applicationId|     |     name      |     |  requirementId   |
                    |documentTypeId|     |     code      |     |  documentTypeId  |
                    |    etc.     |     | description    |     |   isMandatory    |
                    +-------------+     +----------------+     +------------------+
                                                |
                                                v
                                        +--------------------+     +------------------+
                                        | DocTypeAcceptedDoc |---->|  AcceptedDocument|
                                        +--------------------+     +------------------+
                                        |        id          |     |        id        |
                                        |   documentTypeId   |     |       name       |
                                        | acceptedDocumentId |     |       code       |
                                        +--------------------+     |    description   |
                                                                   +------------------+
```

### Tables and Relationships

#### Core Entities

1. **Bank**
    - Primary entity representing a financial institution
    - Fields: id, name, code, establishedDate, active
    - Relationships: One-to-many with Product

2. **Product**
    - Represents a banking product offered by a bank (e.g., Checking Account, Savings Account)
    - Fields: id, bankId, name, code, description, parentId, isActive
    - Relationships:
        - Many-to-one with Bank
        - Self-referential (parentId) for product hierarchy
        - One-to-many with ProductRequirement and ProductDocumentType

3. **Customer**
    - Contains customer information
    - Fields: id, firstName, lastName, email, phoneNumber, dateOfBirth, ssn, address, city, state, zipCode, country, active
    - Relationships: One-to-many with Application and Account

4. **Application**
    - Represents a customer's application for a bank product
    - Fields: id, customerId, productId, applicationNumber, status, submittedDate, reviewedBy, reviewedDate, reviewComments
    - Relationships:
        - Many-to-one with Customer
        - Many-to-one with Product
        - One-to-many with Document
        - One-to-many with ApplicationHistory
        - One-to-many with ApplicationRequirementConsent

5. **Account**
    - Represents an approved and opened bank account
    - Fields: id, customerId, productId, applicationId, accountNumber, status, openedDate, closedDate, closureReason
    - Relationships:
        - Many-to-one with Customer
        - Many-to-one with Product
        - Many-to-one with Application

#### Requirement Entities

6. **Requirement**
    - Defines requirements for various products
    - Fields: id, name, description, code, needsConsent, consentText
    - Relationships:
        - Many-to-many with Product via ProductRequirement
        - Many-to-many with DocumentType via RequirementDocumentType

7. **ProductRequirement**
    - Join table for Product and Requirement
    - Fields: id, productId, requirementId, isMandatory
    - Relationships:
        - Many-to-one with Product
        - Many-to-one with Requirement

8. **ApplicationRequirementConsent**
    - Stores customer consents for application requirements
    - Fields: id, applicationId, requirementId, consentGiven, consentDate, ipAddress, userAgent
    - Relationships:
        - Many-to-one with Application
        - Many-to-one with Requirement

#### Document Entities

9. **DocumentType**
    - Defines types of documents (e.g., ID proof, address proof)
    - Fields: id, name, description, code
    - Relationships:
        - Many-to-many with Product via ProductDocumentType
        - Many-to-many with Requirement via RequirementDocumentType
        - Many-to-many with AcceptedDocument via DocumentTypeAcceptedDocument

10. **ProductDocumentType**
    - Join table for Product and DocumentType
    - Fields: id, productId, documentTypeId, isMandatory
    - Relationships:
        - Many-to-one with Product
        - Many-to-one with DocumentType

11. **RequirementDocumentType**
    - Join table for Requirement and DocumentType
    - Fields: id, requirementId, documentTypeId, isMandatory
    - Relationships:
        - Many-to-one with Requirement
        - Many-to-one with DocumentType

12. **AcceptedDocument**
    - Defines specific accepted document formats (e.g., Passport, Driver's License)
    - Fields: id, name, description, code, isActive
    - Relationships: Many-to-many with DocumentType via DocumentTypeAcceptedDocument

13. **DocumentTypeAcceptedDocument**
    - Join table for DocumentType and AcceptedDocument
    - Fields: id, documentTypeId, acceptedDocumentId
    - Relationships:
        - Many-to-one with DocumentType
        - Many-to-one with AcceptedDocument

14. **Document**
    - Represents an actual document uploaded by a customer
    - Fields: id, applicationId, documentTypeId, acceptedDocumentId, originalFileName, storedFileName, filePath, fileSize, contentType, uploadedDate, isVerified, verifiedBy, verifiedDate, verificationComment
    - Relationships:
        - Many-to-one with Application
        - Many-to-one with DocumentType
        - Many-to-one with AcceptedDocument

#### Tracking Entities

15. **ApplicationHistory**
    - Tracks changes to application status
    - Fields: id, applicationId, previousStatus, newStatus, changedBy, changedDate, comments
    - Relationships: Many-to-one with Application

## Application Flows

### Account Application Flow

1. **Application Submission**
    - Customer selects a bank and product
    - Customer fills in personal details
    - Customer provides required consents
    - System validates the information
    - System creates a new application with SUBMITTED status
    - System checks if the customer already exists, if not creates a new customer record

2. **Application Validation**
    - System checks for duplicate applications
    - System validates that all mandatory consents are provided
    - System validates that required customer information is complete

3. **Document Collection**
    - System determines required documents based on product requirements
    - Customer uploads documents
    - Application status transitions to PENDING_DOCUMENTS
    - Bank staff can verify uploaded documents
    - When all documents are verified, status moves to UNDER_REVIEW

4. **Application Review**
    - Bank staff reviews the application
    - Staff can request additional documents or information (PENDING_DOCUMENTS)
    - Staff may require KYC verification (PENDING_KYC)
    - Staff approves or rejects the application (APPROVED/REJECTED)

5. **Application Status Tracking**
    - All status changes are recorded in ApplicationHistory
    - Application can be in one of these states:
        - DRAFT: Initial incomplete application
        - SUBMITTED: Application submitted for processing
        - UNDER_REVIEW: Application is being reviewed by staff
        - PENDING_DOCUMENTS: Waiting for document uploads or verification
        - PENDING_KYC: Waiting for KYC verification
        - APPROVED: Application approved
        - REJECTED: Application rejected
        - CANCELLED: Application cancelled by customer

### Document Management Flow

1. **Document Type Definition**
    - System administrators define document types (ID proof, address proof, etc.)
    - For each document type, accepted document formats are defined (passport, driver's license, etc.)

2. **Product Document Requirements**
    - Each product has specific document requirements
    - Requirements can be mandatory or optional
    - Products can inherit document requirements from parent products

3. **Document Upload Process**
    - Customer selects document type and specific document format
    - Customer uploads the document file
    - System validates the document against accepted formats
    - System stores the document with metadata

4. **Document Verification**
    - Bank staff reviews uploaded documents
    - Staff marks documents as verified or rejected
    - If documents are rejected, customer is notified to re-upload
    - When all mandatory documents are verified, application can proceed

### Application Status Flow

The application status follows this general flow:

```
DRAFT → SUBMITTED → [PENDING_DOCUMENTS | PENDING_KYC | UNDER_REVIEW] → [APPROVED | REJECTED]
                  → CANCELLED (can happen at any point before approval)
```

Valid status transitions:
- DRAFT → SUBMITTED, CANCELLED
- SUBMITTED → UNDER_REVIEW, PENDING_DOCUMENTS, PENDING_KYC, CANCELLED
- UNDER_REVIEW → APPROVED, REJECTED, PENDING_DOCUMENTS, PENDING_KYC
- PENDING_DOCUMENTS → UNDER_REVIEW, CANCELLED
- PENDING_KYC → UNDER_REVIEW, CANCELLED
- APPROVED → No transitions (terminal state)
- REJECTED → No transitions (terminal state)
- CANCELLED → No transitions (terminal state)

### Account Creation Flow

1. **Application Approval**
    - Application must be in APPROVED status
    - All required documents must be verified

2. **Account Creation**
    - Bank staff initiates account creation
    - System generates a unique account number
    - System creates a new account record with ACTIVE status
    - Account is linked to the customer, product, and application

3. **Account Management**
    - Accounts can be in various states: ACTIVE, CLOSED, FROZEN, DORMANT
    - Accounts can be closed with a closure reason
    - Multiple accounts can be linked to a single customer

## API Endpoints

### Account Applications

- `POST /api/v1/applications`: Create a new application
- `PUT /api/v1/applications/{applicationId}`: Update an existing application
- `GET /api/v1/applications/{applicationId}`: Get application by ID
- `GET /api/v1/applications/{applicationId}/complete-data`: Get complete application data
- `PATCH /api/v1/applications/{applicationId}/status`: Update application status

### Accounts

- `GET /api/v1/accounts/customer/{customerId}`: Get accounts by customer
- `GET /api/v1/accounts/{id}`: Get account by ID
- `GET /api/v1/accounts/number/{accountNumber}`: Get account by account number
- `POST /api/v1/accounts/application/{applicationId}`: Create account from application
- `PATCH /api/v1/accounts/{id}/application-closures`: Close an account

### Banks and Products

- `GET /api/v1/banks`: Get all banks
- `GET /api/v1/banks/{bankId}`: Get bank by ID
- `GET /api/v1/banks/{bankId}/product-hierarchy`: Get bank with product hierarchy
- `GET /api/v1/banks/{bankId}/products`: Get products by bank
- `GET /api/v1/banks/{bankId}/products/{productId}`: Get product by ID
- `GET /api/v1/banks/{bankId}/products/{productId}/product-hierarchy`: Get product with children
- `GET /api/v1/banks/{bankId}/products/{productId}/requirements`: Get requirements by product
- `GET /api/v1/banks/{bankId}/products/{productId}/documents`: Get documents by product
- `GET /api/v1/banks/{bankId}/products/{productId}/details`: Get product with full details

### Customers

- `GET /api/v1/customers/{customerId}`: Get customer by ID
- `GET /api/v1/customers/ssn/{ssn}`: Get customer by SSN
- `GET /api/v1/customers/phone/{phoneNumber}`: Get customer by phone number

### Documents

- `GET /api/v1/application/{applicationId}/documents`: Get documents by application
- `GET /api/v1/documents/{documentTypeId}/accepted-documents`: Get accepted documents by type
- `POST /api/v1/application/{applicationId}/documents`: Upload document
- `PATCH /api/v1/{documentId}/verifications`: Verify document

### Requirements

- `GET /api/v1/requirements`: Get all requirements
- `GET /api/v1/requirements/code/{code}`: Get requirement by code
- `GET /api/v1/requirements/{requirementId}/documents`: Get document types by requirement
- `GET /api/v1/requirements/{requirementId}`: Get requirement document types

## Best Practices and Implementation Notes

1. **Service Layer Architecture**
    - The application follows a clear separation of concerns with controller, service, and repository layers
    - DTOs are used to transfer data between layers
    - Mappers convert between entity and DTO objects

2. **Error Handling**
    - Global exception handling with the GlobalExceptionHandler
    - PlatformException for custom business logic exceptions
    - Consistent error response format using ApiResponse

3. **Event-Driven Design**
    - Events are used for system actions like document verification
    - ApplicationDocumentListener responds to document verification events
    - Asynchronous processing with @Async annotation

4. **Validation**
    - Input validation at controller and service layers
    - Business rule validation (e.g., checking for duplicate applications)
    - Document validation before upload

5. **Hierarchical Data Models**
    - Products can have parent-child relationships
    - Requirements and document types can be inherited from parent products

6. **Status Transition Management**
    - Well-defined application status flow
    - Status changes are tracked in history
    - Status transition rules are enforced in the ApplicationStatusService

7. **Performance Considerations**
    - Database indexes for frequently queried fields
    - Pagination for potentially large result sets (to be implemented)
    - Transactional boundaries for data consistency

8. **Security Features**
    - CORS configuration
    - Input validation to prevent injection attacks
    - Secure file storage for documents
    - IP address and user agent tracking for consents

9. **API Documentation**
    - Swagger/OpenAPI integration
    - Detailed API documentation with @Operation annotations
    - Response and request models defined

10. **Code Organization**
    - Clear package structure
    - Separation of concerns
    - Consistent naming conventions
    - Use of Lombok to reduce boilerplate code

## Code walkthrough
- [Core Domain Model](#core-domain-model)
- [Customer Application Process](#customer-application-process)
- [Document Management Workflow](#document-management-workflow)
- [Application Status Lifecycle](#application-status-lifecycle)
- [Account Creation and Management](#account-creation-and-management)
- [Bank and Product Hierarchy](#bank-and-product-hierarchy)
- [Requirements and Consents Management](#requirements-and-consents-management)
- [Backend Implementation Details](#backend-implementation-details)

## Core Domain Model

The Bank Account Application system revolves around these key concepts:

- **Banks**: Financial institutions that offer various products
- **Products**: Banking products (like checking accounts, savings accounts) that customers can apply for
- **Customers**: Individuals who apply for banking products
- **Applications**: Formal requests by customers to open a specific banking product
- **Requirements**: Conditions that must be met for an application to be approved
- **Documents**: Files that verify customer identity and eligibility
- **Accounts**: Actual bank accounts created after application approval

## Customer Application Process

### 1. Initial Application Creation

When a customer begins the application process:

1. **Customer Selection**:
    - The system first checks if the customer already exists in the database using their SSN
    - If the customer exists, their information is used
    - If not, a new customer record is created with details provided in the application

2. **Application Creation**:
    - The `ApplicationService.createApplication()` method handles the core application creation
    - A unique application ID and application number are generated
    - The application is initially set to `SUBMITTED` status
    - Customer details are validated for completeness
    - The product requested is validated to ensure it's active
    - The system checks for duplicate applications (same customer and product combination)
    - If duplicates exist in certain statuses (`SUBMITTED`, `APPROVED`, `DRAFT`, `UNDER_REVIEW`, `PENDING_DOCUMENTS`, `PENDING_KYC`), an exception is thrown

3. **Requirement Consents**:
    - The system identifies which requirements need customer consent (determined by the `needsConsent` flag)
    - For each mandatory consent requirement, the system verifies the customer has given consent
    - Consents are recorded with IP address and user agent information for audit purposes
    - If mandatory consents are missing, an exception is thrown

4. **History Recording**:
    - An entry is created in the application history table by `ApplicationHistoryService`
    - This tracks the creation of the application with initial `SUBMITTED` status

### 2. Application Update Process

Customers can update their applications under certain conditions:

1. **Update Eligibility**:
    - Only applications in `DRAFT` status can be updated
    - The `ApplicationService.updateApplication()` method enforces this rule

2. **Information Updates**:
    - Customer information can be updated through `CustomerService.updateCustomer()`
    - Product type can be changed only if the application is in an in-progress status

3. **Validation Rules**:
    - Similar validation as creation occurs (mandatory fields, active product, etc.)
    - Product changes trigger re-validation of requirements and consents

## Document Management Workflow

### 1. Document Type Configuration

The system has a hierarchical approach to document management:

1. **Document Types**:
    - Represent categories of documents (e.g., "ID Proof", "Address Proof")
    - Each type has a unique code and description
    - Defined in the `document_type` table

2. **Accepted Documents**:
    - Specific document formats accepted for each document type
    - For example, "Passport", "Driver's License" would be accepted documents for "ID Proof"
    - Defined in `accepted_document` table with relations in `document_type_accepted_document`

3. **Product Document Requirements**:
    - Each product specifies which document types are required
    - Some are marked as mandatory, others as optional
    - Defined in `product_document_type` table
    - Products can inherit document requirements from parent products

4. **Requirement Document Types**:
    - Links requirements to document types that can satisfy them
    - Defined in `requirement_document_type` table

### 2. Document Upload Process

When a customer uploads documents:

1. **Upload Initiation**:
    - Customer selects document type and accepted document format
    - `DocumentService.uploadDocument()` handles the upload process

2. **Document Validation**:
    - System validates that the document type is required for the selected product
    - Validates that the accepted document is valid for the selected document type
    - Performs format validation (file type, size, etc.)

3. **Storage Process**:
    - System creates an application-specific directory
    - Generates a unique filename for the document
    - Stores the document with metadata (original filename, content type, size, etc.)
    - Records document information in the `document` table

4. **Status Update**:
    - If this is the first document uploaded and application is in `SUBMITTED` status, it moves to `PENDING_DOCUMENTS`
    - `updateApplicationStatusAfterDocumentUpload()` handles this transition
    - Creates a history record of the status change

### 3. Document Verification Process

Bank staff verify uploaded documents:

1. **Verification Actions**:
    - Staff can mark documents as verified or rejected via the `DocumentService.verifyDocument()` method
    - Verification includes comments and the identity of the verifier

2. **Event Generation**:
    - When a document is verified, a `DocumentVerifiedEvent` is published
    - `ApplicationDocumentListener` listens for this event

3. **Automatic Status Updates**:
    - The listener checks if all required documents are verified
    - If application is in `PENDING_DOCUMENTS` and all documents are verified, it's moved to `UNDER_REVIEW`
    - This is handled by the event listener asynchronously

4. **Document Verification Checks**:
    - `DocumentService.areAllRequiredDocumentsUploaded()` - Checks if all mandatory document types have at least one document
    - `DocumentService.areAllDocumentsVerified()` - Checks if all uploaded documents are verified

## Application Status Lifecycle

### 1. Status States and Transitions

Applications move through a well-defined lifecycle:

1. **Available Statuses**:
    - `DRAFT`: Initial incomplete application
    - `SUBMITTED`: Application submitted for processing
    - `UNDER_REVIEW`: Application is being reviewed by staff
    - `PENDING_DOCUMENTS`: Waiting for document uploads or verification
    - `PENDING_KYC`: Waiting for KYC verification
    - `APPROVED`: Application approved
    - `REJECTED`: Application rejected
    - `CANCELLED`: Application cancelled by customer

2. **Valid Transitions**:
    - Strictly controlled by `ApplicationStatusService.isValidStatusTransition()`
    - Allowed transitions are defined in `ALLOWED_TRANSITIONS` map:
        - DRAFT → SUBMITTED, CANCELLED
        - SUBMITTED → UNDER_REVIEW, PENDING_DOCUMENTS, PENDING_KYC, CANCELLED
        - UNDER_REVIEW → APPROVED, REJECTED, PENDING_DOCUMENTS, PENDING_KYC
        - PENDING_DOCUMENTS → UNDER_REVIEW, CANCELLED
        - PENDING_KYC → UNDER_REVIEW, CANCELLED
        - APPROVED, REJECTED, CANCELLED → No transitions (terminal states)

### 2. Status Update Process

The `ApplicationStatusService.updateApplicationStatus()` method controls status changes:

1. **Transition Validation**:
    - Verifies that the requested status change is allowed
    - Throws exception if invalid transition is attempted

2. **Special Transition Rules**:
    - To move to `APPROVED`, all requirements must be met:
        - All mandatory consents given
        - All required documents uploaded and verified
    - This is validated by `ApplicationRequirementService.areAllRequirementsMet()`

3. **Status Update Actions**:
    - Updates the application status
    - Records review information if appropriate (reviewer, comments, date)
    - Creates history entry via `ApplicationHistoryService`

### 3. History Tracking

Every status change is recorded:

1. **History Data Captured**:
    - Previous status
    - New status
    - Who made the change
    - When the change was made
    - Comments explaining the change

2. **History Creation**:
    - `ApplicationHistoryService.createHistoryEntryFromStatusUpdate()` creates the records
    - This provides a complete audit trail of an application's journey

## Account Creation and Management

### 1. Account Creation Process

After application approval, accounts are created:

1. **Creation Prerequisites**:
    - Application must be in `APPROVED` status
    - All required documents must be uploaded and verified
    - These are checked in `AccountService.preCheck()`

2. **Account Creation Steps**:
    - Bank staff initiates creation through `AccountService.createAccountFromApplication()`
    - System generates a unique account number
    - Creates an account record with `ACTIVE` status
    - Links it to customer, product, and application

3. **Duplicate Prevention**:
    - Checks if account already exists for the application
    - Throws exception if duplicate is found

### 2. Account Management

Once created, accounts can be managed:

1. **Account Retrieval**:
    - Can be retrieved by ID, account number, or customer
    - `AccountService` provides these methods

2. **Account Status Management**:
    - Accounts can be in these states: `ACTIVE`, `CLOSED`, `FROZEN`, `DORMANT`
    - `AccountService.closeAccount()` allows closing accounts with reason

3. **Account Information**:
    - Account records contain details like opening date, product, customer
    - For closed accounts, closure date and reason are recorded

## Bank and Product Hierarchy

### 1. Bank Structure

Banks are the top-level entities:

1. **Bank Information**:
    - Each bank has a name, code, and establishment date
    - Can be active or inactive
    - Managed by `BankService`

2. **Bank Retrieval**:
    - `BankService.getAllActiveBanks()` gets all active banks
    - Individual banks can be retrieved by ID or code

### 2. Product Hierarchy

Products can have a hierarchical structure:

1. **Product Types**:
    - Each product belongs to a bank
    - Products can have parent-child relationships
    - `Product.parentId` establishes this hierarchy

2. **Hierarchy Management**:
    - `ProductService.getProductWithChildren()` gets a product with its sub-products
    - `ProductService.getProductHierarchyByBank()` gets entire hierarchy for a bank

3. **Inheritance**:
    - Sub-products inherit requirements and document types from parent products
    - This is handled by:
        - `ProductService.getCombinedRequirementsForProduct()`
        - `ProductService.getCombinedDocumentTypesForProduct()`
    - These methods combine requirements and document types from the product and all its ancestors

## Requirements and Consents Management

### 1. Requirement Definition

Requirements define conditions for applications:

1. **Requirement Properties**:
    - Each requirement has a name, code, and description
    - Flag `needsConsent` indicates if customer consent is required
    - If consent is needed, `consentText` provides the text to show to customers

2. **Requirement Association**:
    - Requirements are associated with products via `product_requirement` table
    - Each association can be marked as mandatory or optional

### 2. Consent Management

For requirements needing consent:

1. **Consent Collection**:
    - During application, customers provide consent for requirements
    - Each consent is recorded with application ID, requirement ID, consent status
    - IP address and user agent are recorded for audit purposes

2. **Consent Validation**:
    - `ApplicationService.validateMandatoryConsents()` checks that all required consents are provided
    - `ApplicationRequirementService.areAllRequiredConsentsMet()` verifies consents for status transitions

## Backend Implementation Details

### 1. Service Organization

The application uses a layered architecture:

1. **Controller Layer**:
    - Handles HTTP requests and responses
    - Input validation
    - Authentication and authorization (to be implemented)
    - Examples: `AccountApplicationController`, `BankProductController`

2. **Service Layer**:
    - Contains business logic
    - Transaction management
    - Entity to DTO conversion
    - Examples: `ApplicationService`, `DocumentService`

3. **Repository Layer**:
    - Data access methods
    - Custom queries
    - Examples: `ApplicationRepository`, `CustomerRepository`

### 2. Event-Driven Architecture

Certain processes use events:

1. **Document Verification Events**:
    - `DocumentVerifiedEvent` published when documents are verified
    - `ApplicationDocumentListener` responds to these events
    - Handles automatic status transitions based on document verification

2. **Asynchronous Processing**:
    - Event handlers use `@Async` annotation for non-blocking operations
    - Enables better scaling for document processing

### 3. Error Handling

Robust error handling throughout:

1. **Exception Management**:
    - Custom `PlatformException` for business logic errors
    - `GlobalExceptionHandler` provides centralized exception handling
    - Consistent error response format with `ApiResponse`

2. **Validation Layers**:
    - Controller-level validation with annotations
    - Service-level business rule validation
    - Repository-level constraints

### 4. Data Transfer and Mapping

Clean separation between layers:

1. **DTO Pattern**:
    - DTOs like `ApplicationDTO`, `CustomerDTO` transfer data between layers
    - Prevents exposing internal entity structure
    - Allows custom representations

2. **Mapper Classes**:
    - `AccountMapper`, `DocumentMapper`, etc. convert between entities and DTOs
    - Keep conversion logic centralized
    - Add derived fields like customer names

### 5. Security Considerations

Several security features implemented:

1. **Input Validation**:
    - All user inputs are validated
    - Custom validation in `CustomerDetails.validate()`

2. **File Security**:
    - Safe file storage with unique file names
    - Content type validation
    - Proper exception handling for file operations

3. **Audit Trail**:
    - Comprehensive history tracking
    - Records of who made changes and when
    - IP address tracking for consents