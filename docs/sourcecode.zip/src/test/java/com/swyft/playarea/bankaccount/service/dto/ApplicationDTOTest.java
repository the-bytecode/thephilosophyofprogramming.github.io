package com.swyft.playarea.bankaccount.service.dto;

import com.swyft.playarea.bankaccount.enums.ApplicationStatus;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ApplicationDTOTest {

    public static void main(String[] args) {

        ApplicationDTO applicationDTO = ApplicationDTO.builder()
                .id(UUID.randomUUID().toString())
                .accountType("1")
                .status(ApplicationStatus.SUBMITTED)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .userId("1")
                .build();

        System.out.println(applicationDTO);

    }

}