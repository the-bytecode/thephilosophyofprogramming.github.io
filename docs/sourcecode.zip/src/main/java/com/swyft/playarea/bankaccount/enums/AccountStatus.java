package com.swyft.playarea.bankaccount.enums;

public enum AccountStatus {
    ACTIVE,
    CLOSED,
    FROZEN,
    DORMANT
}
