package com.swyft.playarea.bankaccount.service.dto;

import com.swyft.playarea.bankaccount.enums.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountDTO {
    
    private String id;
    private String customerId;
    private String productId;
    private String applicationId;
    private String accountNumber;
    private AccountStatus status;
    private LocalDateTime openedDate;
    private LocalDateTime closedDate;
    private String closureReason;
    
    // Additional fields for UI display
    private String customerName;
    private String productName;
}
