package com.swyft.playarea.bankaccount.controller.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentUploadRequest {
    private String documentTypeId;
    private String acceptedDocumentId;
}
