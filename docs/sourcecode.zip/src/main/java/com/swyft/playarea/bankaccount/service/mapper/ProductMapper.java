package com.swyft.playarea.bankaccount.service.mapper;

import com.swyft.playarea.bankaccount.data.entities.Product;
import com.swyft.playarea.bankaccount.service.dto.ProductDTO;
import org.springframework.stereotype.Component;

@Component
public class ProductMapper {

    public ProductDTO toDto(Product product) {
        return ProductDTO.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .build();
    }
}
