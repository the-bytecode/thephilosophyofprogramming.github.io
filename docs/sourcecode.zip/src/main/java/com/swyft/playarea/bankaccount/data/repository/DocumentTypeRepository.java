package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.DocumentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DocumentTypeRepository extends JpaRepository<DocumentType, String> {
    
    Optional<DocumentType> findByCode(String code);
    
    @Query("SELECT dt FROM DocumentType dt JOIN ProductDocumentType pdt ON dt.id = pdt.documentTypeId WHERE pdt.productId = :productId")
    List<DocumentType> findByProductId(@Param("productId") String productId);
    
    @Query("SELECT dt FROM DocumentType dt JOIN RequirementDocumentType rdt ON dt.id = rdt.documentTypeId WHERE rdt.requirementId = :requirementId")
    List<DocumentType> findByRequirementId(@Param("requirementId") String requirementId);
}
