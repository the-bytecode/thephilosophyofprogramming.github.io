package com.swyft.playarea.bankaccount.controller.model;

import com.swyft.playarea.bankaccount.PlatformException;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Setter
@Getter
public class CustomerDetails {
    private String firstname;
    private String lastname;
    private String email;
    private String phone;
    private Address address;
    private String ssn;
    private LocalDate dob;

    public void validate() {
        validateCustomerDetails(this);
    }

    /**
     * Validates the customer details in the application request
     * @param customerDetails the customer details to validate
     * @throws PlatformException if validation fails
     */
    private void validateCustomerDetails(CustomerDetails customerDetails) {
        if (customerDetails == null) {
            throw new PlatformException("Customer details cannot be null");
        }

        if (isEmpty(customerDetails.getFirstname())) {
            throw new PlatformException("First name is required");
        }

        if (isEmpty(customerDetails.getLastname())) {
            throw new PlatformException("Last name is required");
        }

        if (isEmpty(customerDetails.getEmail())) {
            throw new PlatformException("Email is required");
        }

        if (isEmpty(customerDetails.getPhone())) {
            throw new PlatformException("Phone number is required");
        }

        if (isEmpty(customerDetails.getSsn())) {
            throw new PlatformException("SSN is required");
        }

        if (customerDetails.getDob() == null) {
            throw new PlatformException("Date of birth is required");
        }

        if (customerDetails.getAddress() == null) {
            throw new PlatformException("Address is required");
        }

        Address address = customerDetails.getAddress();
        if (isEmpty(address.getStreetAddress())) {
            throw new PlatformException("Street address is required");
        }

        if (isEmpty(address.getCity())) {
            throw new PlatformException("City is required");
        }

        if (isEmpty(address.getState())) {
            throw new PlatformException("State is required");
        }

        if (isEmpty(address.getZipCode())) {
            throw new PlatformException("Zip code is required");
        }

        if (isEmpty(address.getCountry())) {
            throw new PlatformException("Country is required");
        }
    }

    private boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
}
