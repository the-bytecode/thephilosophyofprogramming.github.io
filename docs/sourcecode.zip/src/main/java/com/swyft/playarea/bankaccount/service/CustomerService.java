package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.controller.model.Address;
import com.swyft.playarea.bankaccount.controller.model.CustomerDetails;
import com.swyft.playarea.bankaccount.data.repository.CustomerRepository;
import com.swyft.playarea.bankaccount.data.entities.Customer;
import com.swyft.playarea.bankaccount.service.dto.AddressDTO;
import com.swyft.playarea.bankaccount.service.dto.CustomerDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@AllArgsConstructor
public class CustomerService {

    private final CustomerRepository customerRepository;

    @Transactional(readOnly = true)
    public CustomerDTO findCustomerBySsn(String ssn) {
        return customerRepository.findBySsn(ssn).map(
                this::toDTO
        ).orElseThrow(() -> new PlatformException("User not found"));
    }

    @Transactional(readOnly = true)
    public CustomerDTO findCustomerByPhoneNumber(String phoneNumber) {
        return customerRepository.findByPhoneNumber(phoneNumber).map(
                this::toDTO
        ).orElseThrow(() -> new PlatformException("User not found"));

    }

    @Transactional(readOnly = true)
    public CustomerDTO findCustomerById(String id) {
        return customerRepository.findById(id).map(
                this::toDTO
        ).orElseThrow(() -> new PlatformException("User not found"));
    }


    public CustomerDTO getUserById(String userId) {
        Customer customer = getUserEntityOrThrowAnException(userId);
        return toDTO(customer);
    }

    private CustomerDTO toDTO(Customer customer) {
        AddressDTO addressDTO = AddressDTO.builder()
                .streetAddress(customer.getAddress())
                .city(customer.getCity())
                .state(customer.getState())
                .zipCode(customer.getZipCode())
                .country(customer.getCountry())
                .build();

        return CustomerDTO.builder()
                .id(customer.getId())
                .firstname(customer.getFirstName())
                .lastname(customer.getLastName())
                .phone(customer.getPhoneNumber())
                .email(customer.getEmail())
                .address(addressDTO)
                .ssn(customer.getSsn())
                .dob(customer.getDateOfBirth())
                .createdAt(customer.getCreatedAt())
                .updatedAt(customer.getUpdatedAt())
                .build();
    }

    private Customer getUserEntityOrThrowAnException(String userId) {
        Optional<Customer> mayBeUser = customerRepository.findById(userId);
        if (mayBeUser.isEmpty()) {
            throw new PlatformException("User not found");
        }

        return mayBeUser.get();
    }

    public Optional<CustomerDTO> findUserBySSN(String ssn) {

        Optional<Customer> mayBeCustomer = customerRepository.findBySsn(ssn);
        if (mayBeCustomer.isEmpty()) {
            return Optional.empty();
        }

        Customer customer = mayBeCustomer.get();
        CustomerDTO customerDTO = toDTO(customer);
        return Optional.of(customerDTO);
    }

    @Transactional
    public CustomerDTO createCustomer(CustomerDetails customerDetails) {
        LocalDateTime now = LocalDateTime.now();
        Customer customer = Customer.builder()
                .id(UUID.randomUUID().toString())
                .firstName(customerDetails.getFirstname())
                .lastName(customerDetails.getLastname())
                .email(customerDetails.getEmail())
                .phoneNumber(customerDetails.getPhone())
                .address(customerDetails.getAddress().getStreetAddress())
                .city(customerDetails.getAddress().getCity())
                .state(customerDetails.getAddress().getState())
                .zipCode(customerDetails.getAddress().getZipCode())
                .country(customerDetails.getAddress().getCountry())
                .ssn(customerDetails.getSsn())
                .dateOfBirth(customerDetails.getDob())
                .createdAt(now)
                .updatedAt(now)
                .active(true)
                .build();
        Customer savedCustomer = customerRepository.save(customer);

        return toDTO(savedCustomer);
    }

    @Transactional
    public CustomerDTO updateCustomer(String customerId, CustomerDetails customerDetails) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new PlatformException("Customer not found with id: " + customerId));

        // Update customer fields
        customer.setFirstName(customerDetails.getFirstname());
        customer.setLastName(customerDetails.getLastname());
        customer.setEmail(customerDetails.getEmail());
        customer.setPhoneNumber(customerDetails.getPhone());
        Address address = customerDetails.getAddress();
        customer.setAddress(address.getStreetAddress());
        customer.setCity(address.getCity());
        customer.setState(address.getState());
        customer.setZipCode(address.getZipCode());
        customer.setCountry(address.getCountry());

        // SSN and DOB should generally not be updatable once set, but business rules may vary
        customer.setDateOfBirth(customerDetails.getDob());
        customer.setSsn(customerDetails.getSsn());


        customer.setUpdatedAt(LocalDateTime.now());

        Customer updatedCustomer = customerRepository.save(customer);
        return toDTO(updatedCustomer);
    }
}
