package com.swyft.playarea.bankaccount.controller;

import com.swyft.playarea.bankaccount.controller.model.ApplicationRequest;

import com.swyft.playarea.bankaccount.controller.model.ApplicationResponse;
import com.swyft.playarea.bankaccount.service.ApplicationService;
import com.swyft.playarea.bankaccount.service.ApplicationStatusService;
import com.swyft.playarea.bankaccount.service.dto.ApplicationDTO;
import com.swyft.playarea.bankaccount.service.dto.ApplicationDataDTO;
import com.swyft.playarea.bankaccount.service.dto.ApplicationStatusUpdateDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Account Applications", description = "API endpoints for managing account applications")
public class AccountApplicationController {

    private final ApplicationService applicationService;
    private final ApplicationStatusService applicationStatusService;

    @Operation(summary = "Create a new application", description = "Creates a new account application with customer details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Application created successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApplicationResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid input data"),
            @ApiResponse(responseCode = "409", description = "Application already exists")
    })
    @PostMapping("/applications")
    public ApplicationResponse createApplication(@RequestBody ApplicationRequest applicationRequest,
                                                 @RequestHeader(value = "User-Agent", required = false) String userAgent,
                                                 HttpServletRequest request) {

        // Get client IP address
        String ipAddress = getClientIp(request);

        return applicationService.createApplication(applicationRequest, ipAddress, userAgent);

    }

    @Operation(summary = "Update an existing application", description = "Updates an existing application with new details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Application updated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input data"),
            @ApiResponse(responseCode = "404", description = "Application not found")
    })
    @PutMapping("/applications/{applicationId}")
    public ApplicationResponse updateApplication(@PathVariable String applicationId, @RequestBody ApplicationRequest applicationRequest) {
        return applicationService.updateApplication(applicationId, applicationRequest);
    }

    @Operation(summary = "Get application by ID", description = "Retrieves an application by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Application found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApplicationDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Application not found")
    })
    @GetMapping("/applications/{applicationId}")
    public ApplicationDTO getAccountById(@PathVariable String applicationId) {
        return applicationService.getApplicationById(applicationId);

    }

    @Operation(summary = "Get complete application data", description = "Retrieves complete application data including customer details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Application data found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApplicationDataDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Application not found")
    })
    @GetMapping("/applications/{applicationId}/complete-data")
    public ApplicationDataDTO getCompleteApplicationDataById(@PathVariable String applicationId) {
        return applicationService.getCompleteApplicationDataByApplicationId(applicationId);

    }

    @Operation(summary = "Update application status", description = "Updates the status of an existing application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Status updated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid status transition"),
            @ApiResponse(responseCode = "404", description = "Application not found")
    })
    @PatchMapping("/applications/{applicationId}/status")
    public ResponseEntity<Void> updateApplicationStatus(
            @PathVariable String applicationId,
            @RequestBody ApplicationStatusUpdateDTO statusUpdateDTO) {
        applicationStatusService.updateApplicationStatus(applicationId, statusUpdateDTO);
        return ResponseEntity.noContent().build();
    }

    /**
     * Helper method to get client IP address from request
     */
    private String getClientIp(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            // In case of multiple proxies, the first IP is the original client
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
