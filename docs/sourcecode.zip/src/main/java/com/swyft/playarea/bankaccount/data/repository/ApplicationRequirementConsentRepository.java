package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.ApplicationRequirementConsent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationRequirementConsentRepository extends JpaRepository<ApplicationRequirementConsent, String> {
    
    List<ApplicationRequirementConsent> findByApplicationId(String applicationId);
    
    List<ApplicationRequirementConsent> findByApplicationIdAndRequirementId(String applicationId, String requirementId);
    
    boolean existsByApplicationIdAndRequirementIdAndConsentGiven(String applicationId, String requirementId, Boolean consentGiven);
}
