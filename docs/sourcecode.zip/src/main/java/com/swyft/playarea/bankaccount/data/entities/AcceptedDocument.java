package com.swyft.playarea.bankaccount.data.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "accepted_document", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AcceptedDocument extends BaseEntity {
    
    @Column(name = "name", nullable = false, length = 100)
    private String name;
    
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    
    @Column(name = "code", nullable = false, unique = true, length = 50)
    private String code;
    
    @Column(name = "is_active")
    private Boolean isActive = Boolean.TRUE;
}
