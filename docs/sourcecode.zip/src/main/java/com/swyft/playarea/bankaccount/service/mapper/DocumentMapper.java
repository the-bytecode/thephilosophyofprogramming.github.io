package com.swyft.playarea.bankaccount.service.mapper;

import com.swyft.playarea.bankaccount.data.entities.Document;
import com.swyft.playarea.bankaccount.data.repository.AcceptedDocumentRepository;
import com.swyft.playarea.bankaccount.service.AcceptedDocumentService;
import com.swyft.playarea.bankaccount.service.DocumentService;
import com.swyft.playarea.bankaccount.service.DocumentTypeService;
import com.swyft.playarea.bankaccount.service.dto.AcceptedDocumentDTO;
import com.swyft.playarea.bankaccount.service.dto.DocumentDTO;
import com.swyft.playarea.bankaccount.service.dto.DocumentTypeDTO;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@AllArgsConstructor
public class DocumentMapper {
    private final AcceptedDocumentService acceptedDocumentService;
    private final DocumentTypeService documentTypeService;

    public DocumentDTO toDto(Document document) {
        return DocumentDTO.builder()
                .id(document.getId())
                .applicationId(document.getApplicationId())
                .documentTypeId(document.getDocumentTypeId())
                .acceptedDocumentId(document.getAcceptedDocumentId())
                .originalFileName(document.getOriginalFileName())
                .storedFileName(document.getStoredFileName())
                .filePath(document.getFilePath())
                .fileSize(document.getFileSize())
                .contentType(document.getContentType())
                .uploadedDate(document.getUploadedDate())
                .isVerified(document.getIsVerified())
                .verifiedBy(document.getVerifiedBy())
                .verifiedDate(document.getVerifiedDate())
                .verificationComment(document.getVerificationComment())
                .documentTypeName(getDocumentTypeNameById(document.getDocumentTypeId()))
                .acceptedDocumentName(getAcceptedDocumentNameById(document.getAcceptedDocumentId()))
                .build();
    }

    private String getAcceptedDocumentNameById(String acceptedDocumentId) {
        Optional<AcceptedDocumentDTO> optionalAcceptedDocumentDTO = acceptedDocumentService.findById(acceptedDocumentId);
        return optionalAcceptedDocumentDTO.map(AcceptedDocumentDTO::getName).orElse(StringUtils.EMPTY);
    }

    private String getDocumentTypeNameById(String documentTypeId) {
        Optional<DocumentTypeDTO> optionalDocumentTypeName = documentTypeService.findById(documentTypeId);
        return optionalDocumentTypeName.map(DocumentTypeDTO::getName).orElse(StringUtils.EMPTY);
    }
}
