package com.swyft.playarea.bankaccount.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class AppConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // URL patterns to allow CORS requests
                .allowedOrigins("*") // Allow requests from all origins
                .allowedMethods("GET", "POST", "PUT", "DELETE",
                        "PATCH") // Allow GET, POST, PATCH, PUT, and DELETE methods
                .allowedHeaders("*") // Allow all headers
                .maxAge(3600); // Set the maximum age of the CORS response to 1 hour (3600 seconds)
    }
}
