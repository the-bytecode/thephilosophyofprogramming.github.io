package com.swyft.playarea.bankaccount.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RequirementDTO {
    
    private String id;
    private String name;
    private String description;
    private String code;
    private Boolean needsConsent;
    private String consentText;
    
    // Additional fields
    private Boolean isMandatory; // Whether it's mandatory for a specific product
    private List<DocumentTypeDTO> documentTypes;
}
