package com.swyft.playarea.bankaccount.data.entities;

import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@Table(name = "application", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Application extends BaseEntity {
    
    @Column(name = "customer_id", nullable = false, length = 36)
    private String customerId;
    
    @Column(name = "product_id", nullable = false, length = 36)
    private String productId;
    
    @Column(name = "application_number", nullable = false, unique = true, length = 50)
    private String applicationNumber;
    
    @Column(name = "status", nullable = false, length = 36)
    @Enumerated(EnumType.STRING)
    private ApplicationStatus status;
    
    @Column(name = "submitted_date", nullable = false)
    private LocalDateTime submittedDate;
    
    @Column(name = "reviewed_by", length = 100)
    private String reviewedBy;
    
    @Column(name = "reviewed_date")
    private LocalDateTime reviewedDate;
    
    @Column(name = "review_comments", columnDefinition = "TEXT")
    private String reviewComments;
}
