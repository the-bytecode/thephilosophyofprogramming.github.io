package com.swyft.playarea.bankaccount.controller;

import com.swyft.playarea.bankaccount.service.AccountService;
import com.swyft.playarea.bankaccount.service.dto.AccountDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
@Tag(name = "Accounts", description = "API endpoints for managing bank accounts")
public class AccountController {

    private final AccountService accountService;

    @Operation(summary = "Get accounts by customer", description = "Retrieves all accounts owned by a specific customer")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Accounts retrieved successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AccountDTO.class, type = "array"))}),
            @ApiResponse(responseCode = "404", description = "Customer not found")
    })
    @GetMapping("/customer/{customerId}")
    public List<AccountDTO> getAccountsByCustomer(@PathVariable String customerId) {
        return accountService.getAccountsByCustomerId(customerId);
    }

    @Operation(summary = "Get account by ID", description = "Retrieves an account by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AccountDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Account not found")
    })
    @GetMapping("/{id}")
    public AccountDTO getAccountById(@PathVariable String id) {
        return accountService.getAccountById(id);
    }

    @Operation(summary = "Get account by account number", description = "Retrieves an account by its account number")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account found",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AccountDTO.class))}),
            @ApiResponse(responseCode = "404", description = "Account not found")
    })
    @GetMapping("/number/{accountNumber}")
    public AccountDTO getAccountByNumber(@PathVariable String accountNumber) {
        return accountService.getAccountByAccountNumber(accountNumber);
    }

    @Operation(summary = "Create account from application", description = "Creates a new account based on an approved application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account created successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AccountDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Application not approved or documents incomplete"),
            @ApiResponse(responseCode = "404", description = "Application not found"),
            @ApiResponse(responseCode = "409", description = "Account already exists for this application")
    })
    @PostMapping("/application/{applicationId}")
    public AccountDTO createAccountFromApplication(@PathVariable String applicationId) {
        return accountService.createAccountFromApplication(applicationId);
    }

    @Operation(summary = "Close an account", description = "Closes an active account with a closure reason")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Account closed successfully",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AccountDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid operation for account status"),
            @ApiResponse(responseCode = "404", description = "Account not found")
    })
    @PatchMapping("/{id}/application-closures")
    public AccountDTO closeAccount(
            @PathVariable String id,
            @RequestParam String closureReason) {
        return accountService.closeAccount(id, closureReason);
    }
}
