package com.swyft.playarea.bankaccount.data.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;

@Entity
@Table(name = "customer", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Customer extends BaseEntity {
    
    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;
    
    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;
    
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;
    
    @Column(name = "phone_number", nullable = false, length = 20)
    private String phoneNumber;
    
    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;
    
    @Column(name = "ssn", nullable = false, unique = true, length = 20)
    private String ssn;
    
    @Column(name = "address", nullable = false)
    private String address;
    
    @Column(name = "city", nullable = false, length = 50)
    private String city;
    
    @Column(name = "state", nullable = false, length = 50)
    private String state;
    
    @Column(name = "zip_code", nullable = false, length = 20)
    private String zipCode;
    
    @Column(name = "country", nullable = false, length = 50)
    private String country;
    
    @Column(name = "active")
    @Builder.Default
    private Boolean active = Boolean.TRUE;
}
