package com.swyft.playarea.bankaccount.data.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "product_requirement", schema = "bank_account")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductRequirement extends BaseEntity {
    
    @Column(name = "product_id", nullable = false, length = 36)
    private String productId;
    
    @Column(name = "requirement_id", nullable = false, length = 36)
    private String requirementId;
    
    @Column(name = "is_mandatory")
    private Boolean isMandatory = Boolean.TRUE;
}
