package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.data.entities.ApplicationHistory;
import com.swyft.playarea.bankaccount.data.repository.ApplicationHistoryRepository;
import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import com.swyft.playarea.bankaccount.service.dto.ApplicationStatusUpdateDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ApplicationHistoryService {

    private final ApplicationHistoryRepository applicationHistoryRepository;

    /**
     * Retrieves application history for a specific application ID sorted by most recent first
     *
     * @param applicationId the ID of the application
     * @return list of application history entries
     */
    @Transactional(readOnly = true)
    public List<ApplicationHistory> getApplicationHistory(String applicationId) {
        log.debug("Retrieving history for application ID: {}", applicationId);
        return applicationHistoryRepository.findByApplicationIdOrderByChangedDateDesc(applicationId);
    }

    /**
     * Creates a new application history entry
     *
     * @param applicationId  the ID of the application
     * @param previousStatus the previous status
     * @param newStatus      the new status
     * @param changedBy      the user who made the change
     * @param comments       any comments about the change
     * @return the saved application history entry
     */
    @Transactional
    public ApplicationHistory createHistoryEntry(
            String applicationId,
            ApplicationStatus previousStatus,
            ApplicationStatus newStatus,
            String changedBy,
            String comments) {

        log.debug("Creating history entry for application ID: {}", applicationId);

        ApplicationHistory historyEntry = ApplicationHistory.builder()
                .applicationId(applicationId)
                .previousStatus(previousStatus)
                .newStatus(newStatus)
                .changedBy(changedBy)
                .changedDate(LocalDateTime.now())
                .comments(comments)
                .build();

        return applicationHistoryRepository.save(historyEntry);
    }

    /**
     * Creates a history entry from a status update DTO
     *
     * @param applicationId   the ID of the application
     * @param currentStatus   the current status
     * @param newStatus       the new status
     * @param statusUpdateDTO DTO containing update information
     */
    @Transactional
    public void createHistoryEntryFromStatusUpdate(
            String applicationId,
            ApplicationStatus currentStatus,
            ApplicationStatus newStatus,
            ApplicationStatusUpdateDTO statusUpdateDTO) {

        log.debug("Creating history entry from status update for application ID: {}", applicationId);

        ApplicationHistory historyEntry = createHistoryEntry(
                applicationId,
                currentStatus,
                newStatus,
                statusUpdateDTO.getChangedBy(),
                statusUpdateDTO.getComments()
        );
        applicationHistoryRepository.save(historyEntry);
        log.debug("History entry created for application ID: {}", applicationId);
    }
}