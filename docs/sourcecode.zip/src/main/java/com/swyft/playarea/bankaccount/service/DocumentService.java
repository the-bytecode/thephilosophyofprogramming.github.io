package com.swyft.playarea.bankaccount.service;

import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.controller.model.DocumentUploadRequest;
import com.swyft.playarea.bankaccount.data.entities.*;
import com.swyft.playarea.bankaccount.data.repository.*;

import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import com.swyft.playarea.bankaccount.event.DocumentVerifiedEvent;
import com.swyft.playarea.bankaccount.service.dto.AcceptedDocumentDTO;
import com.swyft.playarea.bankaccount.service.dto.DocumentDTO;
import com.swyft.playarea.bankaccount.service.dto.DocumentTypeDTO;
import com.swyft.playarea.bankaccount.service.dto.ProductDocumentTypeDTO;
import com.swyft.playarea.bankaccount.service.mapper.AcceptedDocumentMapper;
import com.swyft.playarea.bankaccount.service.mapper.DocumentMapper;
import com.swyft.playarea.bankaccount.service.mapper.DocumentTypeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final DocumentTypeRepository documentTypeRepository;
    private final AcceptedDocumentRepository acceptedDocumentRepository;
    private final ProductDocumentTypeRepository productDocumentTypeRepository;
    private final DocumentTypeAcceptedDocumentRepository documentTypeAcceptedDocumentRepository;
    private final ApplicationRepository applicationRepository;
    private final DocumentMapper documentMapper;
    private final DocumentTypeMapper documentTypeMapper;
    private final AcceptedDocumentMapper acceptedDocumentMapper;
    private final ProductRepository productRepository;
    private final ApplicationEventPublisher eventPublisher;
    private final ApplicationHistoryService applicationHistoryService;

    @Value("${app.document.upload-dir:./uploads}")
    private String baseUploadDir;

    @Transactional(readOnly = true)
    public List<DocumentDTO> getDocumentsByApplicationId(String applicationId) {
        List<Document> documents = documentRepository.findByApplicationId(applicationId);
        return documents.stream()
                .map(documentMapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<DocumentTypeDTO> getRequiredDocumentTypesByProductId(String productId) {
        List<DocumentType> documentTypes = documentTypeRepository.findByProductId(productId);
        return documentTypes.stream()
                .map(documentTypeMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AcceptedDocumentDTO> getAcceptedDocumentsByDocumentTypeId(String documentTypeId) {
        // Get the join records first
        List<DocumentTypeAcceptedDocument> joinRecords = documentTypeAcceptedDocumentRepository.findByDocumentTypeId(documentTypeId);

        // Extract acceptedDocumentIds from join records
        List<String> acceptedDocumentIds = joinRecords.stream()
                .map(DocumentTypeAcceptedDocument::getAcceptedDocumentId)
                .collect(Collectors.toList());

        // Fetch the active accepted documents
        List<AcceptedDocument> acceptedDocuments = acceptedDocumentRepository.findAllById(acceptedDocumentIds).stream()
                .filter(AcceptedDocument::getIsActive)
                .toList();

        // Map to DTOs
        return acceptedDocuments.stream()
                .map(acceptedDocumentMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public DocumentDTO verifyDocument(String documentId, String verifiedBy, String verificationComment, Boolean isVerified) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new PlatformException("Document not found"));

        document.setIsVerified(isVerified);
        document.setVerifiedBy(verifiedBy);
        document.setVerifiedDate(LocalDateTime.now());
        document.setVerificationComment(verificationComment);

        Document updatedDocument = documentRepository.save(document);

        // Publish document verification event
        DocumentVerifiedEvent documentVerifiedEvent = new DocumentVerifiedEvent(
                updatedDocument.getApplicationId(),
                documentId,
                isVerified,
                verifiedBy);
        eventPublisher.publishEvent(documentVerifiedEvent);

        return documentMapper.toDto(updatedDocument);
    }

    @Transactional(readOnly = true)
    public boolean areAllRequiredDocumentsUploaded(String applicationId, String productId) {
        // Get all mandatory document types for the product
        List<ProductDocumentType> mandatoryDocTypes = productDocumentTypeRepository
                .findByProductIdAndIsMandatory(productId, true);

        if (mandatoryDocTypes.isEmpty()) {
            return true; // No mandatory documents required
        }

        // Get all uploaded documents for the application
        List<Document> uploadedDocs = documentRepository.findByApplicationId(applicationId);

        // Check if all mandatory document types have at least one uploaded document
        return mandatoryDocTypes.stream()
                .allMatch(mandatoryDocType -> uploadedDocs.stream()
                        .anyMatch(doc -> doc.getDocumentTypeId().equals(mandatoryDocType.getDocumentTypeId())));
    }

    @Transactional(readOnly = true)
    public boolean areAllDocumentsVerified(String applicationId) {
        List<Document> documents = documentRepository.findByApplicationId(applicationId);

        if (documents.isEmpty()) {
            return false; // No documents uploaded yet
        }

        return documents.stream().allMatch(Document::getIsVerified);
    }

    private String createApplicationDirectory(String applicationId) throws IOException {
        String applicationDirPath = baseUploadDir + "/application_" + applicationId;
        Path path = Paths.get(applicationDirPath);

        if (!Files.exists(path)) {
            Files.createDirectories(path);
        }

        return applicationDirPath;
    }

    private String generateUniqueFileName(String originalFilename) {
        if (originalFilename == null || originalFilename.isEmpty()) {
            throw new PlatformException("Invalid file name");
        }
        // Extract file extension
        String fileExtension = "";
        int lastDotIndex = originalFilename.lastIndexOf('.');
        if (lastDotIndex > 0) {
            fileExtension = originalFilename.substring(lastDotIndex);
        }

        // Generate unique name with UUID
        return UUID.randomUUID() + fileExtension;
    }


    @Transactional(readOnly = true)
    public List<ProductDocumentTypeDTO> getDocumentTypesByProductId(String productId) {
        List<ProductDocumentType> productDocumentTypes = productDocumentTypeRepository.findByProductId(productId);
        List<ProductDocumentTypeDTO> result = new ArrayList<>();

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        for (ProductDocumentType pdt : productDocumentTypes) {
            DocumentType documentType = documentTypeRepository.findById(pdt.getDocumentTypeId())
                    .orElseThrow(() -> new PlatformException("Document type not found with id: " + pdt.getDocumentTypeId()));

            ProductDocumentTypeDTO dto = ProductDocumentTypeDTO.builder()
                    .id(pdt.getId())
                    .productId(productId)
                    .productName(product.getName())
                    .documentTypeId(documentType.getId())
                    .documentTypeName(documentType.getName())
                    .documentTypeDescription(documentType.getDescription())
                    .documentTypeCode(documentType.getCode())
                    .isMandatory(pdt.getIsMandatory())
                    .build();

            // Add accepted documents for this document type
            dto.setAcceptedDocuments(getAcceptedDocumentsByDocumentTypeId(documentType.getId()));

            result.add(dto);
        }

        return result;
    }

    /**
     * Validates that the document being uploaded is of an accepted type for the given application
     *
     * @param applicationId      the application ID
     * @param documentTypeId     the document type ID
     * @param acceptedDocumentId the accepted document ID
     * @throws PlatformException if the document is not valid for the application
     */
    private void validateDocumentUpload(String applicationId, String documentTypeId, String acceptedDocumentId) {
        // Verify application exists
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new PlatformException("Application not found"));

        // Get the product for this application
        String productId = application.getProductId();

        // Get all document types required for this product (including from parent products)
        List<ProductDocumentTypeDTO> productDocTypes = productRepository.findById(productId)
                .map(product -> {
                    if (product.getParentId() != null) {
                        return getCombinedDocumentTypesForProduct(productId);
                    } else {
                        return getDocumentTypesByProductId(productId);
                    }
                })
                .orElseThrow(() -> new PlatformException("Product not found"));

        // Check if the document type is required for this product
        boolean isValidDocType = productDocTypes.stream()
                .anyMatch(docType -> docType.getDocumentTypeId().equals(documentTypeId));

        if (!isValidDocType) {
            throw new PlatformException("Document type is not valid for this product");
        }

        // Check if the accepted document is valid for this document type
        List<AcceptedDocumentDTO> acceptedDocs = getAcceptedDocumentsByDocumentTypeId(documentTypeId);
        boolean isValidAcceptedDoc = acceptedDocs.stream()
                .anyMatch(accDoc -> accDoc.getId().equals(acceptedDocumentId));

        if (!isValidAcceptedDoc) {
            throw new PlatformException("Document is not an accepted type for this document category");
        }
    }

    /**
     * Gets all document types for a product, including those inherited from parent products.
     *
     * @param productId The ID of the product
     * @return List of all document types (from product and its parents)
     */
    @Transactional(readOnly = true)
    public List<ProductDocumentTypeDTO> getCombinedDocumentTypesForProduct(String productId) {
        // Get the product
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        // Get direct document types for this product
        List<ProductDocumentTypeDTO> directDocTypes = getDocumentTypesByProductId(productId);

        // If product has no parent, return only its document types
        if (product.getParentId() == null) {
            return directDocTypes;
        }

        // Get parent product document types
        List<ProductDocumentTypeDTO> parentDocTypes = getCombinedDocumentTypesForProduct(product.getParentId());

        // Create a map of document type IDs to detect duplicates
        Map<String, ProductDocumentTypeDTO> docTypesMap = new HashMap<>();

        // Add parent document types first (will be overridden by child document types if duplicates exist)
        parentDocTypes.forEach(docType -> docTypesMap.put(docType.getDocumentTypeId(), docType));

        // Add direct document types (overriding parent document types if same ID)
        directDocTypes.forEach(docType -> docTypesMap.put(docType.getDocumentTypeId(), docType));

        // Return combined list
        return new ArrayList<>(docTypesMap.values());
    }

    @Transactional
    public DocumentDTO uploadDocument(String applicationId, MultipartFile file, DocumentUploadRequest documentUploadRequest) {
        try {
            // Validate document type and accepted document
            validateDocumentUpload(
                    applicationId,
                    documentUploadRequest.getDocumentTypeId(),
                    documentUploadRequest.getAcceptedDocumentId()
            );

            // Create application-specific directory structure
            String applicationDirPath = createApplicationDirectory(applicationId);

            // Generate a unique filename for storing
            String storedFileName = generateUniqueFileName(file.getOriginalFilename());

            // Store the file
            Path targetLocation = Paths.get(applicationDirPath).resolve(storedFileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            // Create document entity
            Document document = Document.builder()
                    .id(UUID.randomUUID().toString())
                    .applicationId(applicationId)
                    .uploadedDate(LocalDateTime.now())
                    .documentTypeId(documentUploadRequest.getDocumentTypeId())
                    .acceptedDocumentId(documentUploadRequest.getAcceptedDocumentId())
                    .originalFileName(file.getOriginalFilename())
                    .storedFileName(storedFileName)
                    .filePath(targetLocation.toString())
                    .fileSize(file.getSize())
                    .contentType(file.getContentType())
                    .isVerified(false)
                    .build();

            Document savedDocument = documentRepository.save(document);

            // After saving document, check if application status needs to be updated
            updateApplicationStatusAfterDocumentUpload(applicationId);

            return documentMapper.toDto(savedDocument);

        } catch (IOException ex) {
            throw new PlatformException("Could not store file " + file.getOriginalFilename(), ex);
        }
    }

    /**
     * Updates application status after document upload if needed
     *
     * @param applicationId the application ID
     */
    private void updateApplicationStatusAfterDocumentUpload(String applicationId) {
        applicationRepository.findById(applicationId).ifPresent(application -> {
            // If application is in SUBMITTED status, change to PENDING_DOCUMENTS
            if (application.getStatus() == ApplicationStatus.SUBMITTED) {
                application.setStatus(ApplicationStatus.PENDING_DOCUMENTS);
                application.setUpdatedAt(LocalDateTime.now());
                applicationRepository.save(application);

                // Create history record
                applicationHistoryService.createHistoryEntry(
                        applicationId,
                        ApplicationStatus.SUBMITTED,
                        ApplicationStatus.PENDING_DOCUMENTS,
                        "SYSTEM",
                        "Document uploaded, waiting for verification"
                );

            }
        });
    }
}