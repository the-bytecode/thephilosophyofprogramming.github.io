package com.swyft.playarea.bankaccount.service.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationStatusUpdateDTO {
    private String newStatus;
    private String changedBy;
    private String comments;
    @Builder.Default
    private LocalDateTime at = LocalDateTime.now();
}