package com.swyft.playarea.bankaccount.service.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequirementConsentDTO {
    private String requirementId;
    private Boolean consentGiven;
}
