package com.swyft.playarea.bankaccount.service;


import com.swyft.playarea.bankaccount.PlatformException;
import com.swyft.playarea.bankaccount.data.entities.Product;

import com.swyft.playarea.bankaccount.data.repository.ProductRepository;
import com.swyft.playarea.bankaccount.service.dto.*;
import com.swyft.playarea.bankaccount.service.mapper.ProductMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper productMapper;
    private final RequirementService requirementService;
    private final DocumentService documentService;

    @Transactional(readOnly = true)
    public List<ProductDTO> getProductsByBank(String bankId) {
        // Find top-level products (those with null parentId) for this bank
        List<Product> products = productRepository.findByBankIdAndIsActiveTrue(bankId)
                .stream()
                .filter(product -> product.getParentId() == null)
                .toList();

        return products.stream()
                .map(productMapper::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductDTO> getProductHierarchyByBank(String bankId) {
        // Find top-level products (those with null parentId) for this bank
        List<Product> topProducts = productRepository.findByBankIdAndIsActiveTrue(bankId)
                .stream()
                .filter(product -> product.getParentId() == null)
                .toList();

        // For each top-level product, recursively fetch all sub-products
        return topProducts.stream()
                .map(product -> getProductWithChildren(product.getId()))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductDTO getProductWithChildren(String productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        ProductDTO productDTO = productMapper.toDto(product);

        // Find all direct sub-products
        List<Product> subProducts = productRepository.findByParentIdAndIsActiveTrue(productId);
        if (!subProducts.isEmpty()) {
            List<ProductDTO> subProductDTOs = new ArrayList<>();

            // Recursively fetch children for each sub-product
            for (Product subProduct : subProducts) {
                subProductDTOs.add(getProductWithChildren(subProduct.getId()));
            }

            productDTO.setSubProducts(subProductDTOs);
        }

        return productDTO;
    }

    @Transactional(readOnly = true)
    public ProductDTO getProductById(String id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + id));

        return productMapper.toDto(product);
    }

    @Transactional(readOnly = true)
    public ProductDTO getProductByBankAndCode(String bankId, String code) {
        Product product = productRepository.findByBankIdAndCode(bankId, code)
                .orElseThrow(() -> new PlatformException(
                        "Product not found with bank id: " + bankId + " and code: " + code));

        return productMapper.toDto(product);
    }

    @Transactional(readOnly = true)
    public ProductDTO getProductWithRequirementsAndDocuments(String productId) {
        // Get product details
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        ProductDTO productDTO = productMapper.toDto(product);

        // Get combined requirements from this product and its parents
        List<ProductRequirementDTO> combinedRequirements = getCombinedRequirementsForProduct(productId);

        // Map them to RequirementDTO for the response
        productDTO.setRequirements(combinedRequirements.stream()
                .map(pr -> {
                    RequirementDTO requirementDTO = new RequirementDTO();
                    requirementDTO.setId(pr.getRequirementId());
                    requirementDTO.setName(pr.getRequirementName());
                    requirementDTO.setDescription(pr.getRequirementDescription());
                    requirementDTO.setCode(pr.getRequirementCode());
                    requirementDTO.setIsMandatory(pr.getIsMandatory());

                    // Get document types for this requirement
                    requirementDTO.setDocumentTypes(requirementService.getDocumentTypesByRequirementId(pr.getRequirementId()));

                    return requirementDTO;
                })
                .collect(Collectors.toList()));

        // Get combined document types from this product and its parents
        List<ProductDocumentTypeDTO> combinedDocTypes = getCombinedDocumentTypesForProduct(productId);

        // Map them to DocumentTypeDTO for the response
        productDTO.setDocumentTypes(combinedDocTypes.stream()
                .map(pdt -> {
                    DocumentTypeDTO documentTypeDTO = new DocumentTypeDTO();
                    documentTypeDTO.setId(pdt.getDocumentTypeId());
                    documentTypeDTO.setName(pdt.getDocumentTypeName());
                    documentTypeDTO.setDescription(pdt.getDocumentTypeDescription());
                    documentTypeDTO.setCode(pdt.getDocumentTypeCode());
                    documentTypeDTO.setIsMandatory(pdt.getIsMandatory());
                    documentTypeDTO.setAcceptedDocuments(pdt.getAcceptedDocuments());

                    return documentTypeDTO;
                })
                .collect(Collectors.toList()));

        return productDTO;
    }

    /**
     * Gets all requirements for a product, including those inherited from parent products.
     *
     * @param productId The ID of the product
     * @return List of all requirements (from product and its parents)
     */
    @Transactional(readOnly = true)
    public List<ProductRequirementDTO> getCombinedRequirementsForProduct(String productId) {
        // Get the product
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        // Get direct requirements for this product
        List<ProductRequirementDTO> directRequirements = requirementService.getRequirementsByProductId(productId);

        // If product has no parent, return only its requirements
        if (product.getParentId() == null) {
            return directRequirements;
        }

        // Get parent product requirements
        List<ProductRequirementDTO> parentRequirements = getCombinedRequirementsForProduct(product.getParentId());

        // Create a map of requirement IDs to detect duplicates
        Map<String, ProductRequirementDTO> requirementsMap = new HashMap<>();

        // Add parent requirements first (will be overridden by child requirements if duplicates exist)
        parentRequirements.forEach(req -> requirementsMap.put(req.getRequirementId(), req));

        // Add direct requirements (overriding parent requirements if same ID)
        directRequirements.forEach(req -> requirementsMap.put(req.getRequirementId(), req));

        // Return combined list
        return new ArrayList<>(requirementsMap.values());
    }

    /**
     * Gets all document types for a product, including those inherited from parent products.
     *
     * @param productId The ID of the product
     * @return List of all document types (from product and its parents)
     */
    @Transactional(readOnly = true)
    public List<ProductDocumentTypeDTO> getCombinedDocumentTypesForProduct(String productId) {
        // Get the product
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        // Get direct document types for this product
        List<ProductDocumentTypeDTO> directDocTypes = documentService.getDocumentTypesByProductId(productId);

        // If product has no parent, return only its document types
        if (product.getParentId() == null) {
            return directDocTypes;
        }

        // Get parent product document types
        List<ProductDocumentTypeDTO> parentDocTypes = getCombinedDocumentTypesForProduct(product.getParentId());

        // Create a map of document type IDs to detect duplicates
        Map<String, ProductDocumentTypeDTO> docTypesMap = new HashMap<>();

        // Add parent document types first (will be overridden by child document types if duplicates exist)
        parentDocTypes.forEach(docType -> docTypesMap.put(docType.getDocumentTypeId(), docType));

        // Add direct document types (overriding parent document types if same ID)
        directDocTypes.forEach(docType -> docTypesMap.put(docType.getDocumentTypeId(), docType));

        // Return combined list
        return new ArrayList<>(docTypesMap.values());
    }

    @Transactional(readOnly = true)
    public List<ProductRequirementDTO> getRequirementsByProduct(String productId) {
        // Verify product exists
        throwExceptionIfProductNotExists(productId);

        // Get requirements for this product
        return requirementService.getRequirementsByProductId(productId);
    }

    private void throwExceptionIfProductNotExists(String productId) {
        boolean exists = productRepository.existsById(productId);
        if (!exists) {
            throw new PlatformException("Product not found with id: " + productId);
        }
    }

    @Transactional(readOnly = true)
    public List<ProductDocumentTypeDTO> getDocumentTypesByProduct(String productId) {
        // Verify product exists
        throwExceptionIfProductNotExists(productId);

        // Get document types for this product
        return documentService.getDocumentTypesByProductId(productId);
    }

    @Transactional(readOnly = true)
    public boolean isProductActive(String productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new PlatformException("Product not found with id: " + productId));

        return product.getIsActive();
    }
}
