package com.swyft.playarea.bankaccount.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductRequirementDTO {
    
    private String id;
    private String productId;
    private String productName;
    private String requirementId;
    private String requirementName;
    private String requirementDescription;
    private String requirementCode;
    private Boolean isMandatory;
}
