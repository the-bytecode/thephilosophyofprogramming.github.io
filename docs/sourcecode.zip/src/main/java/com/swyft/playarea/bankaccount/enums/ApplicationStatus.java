package com.swyft.playarea.bankaccount.enums;

import java.util.List;
import java.util.Optional;

public enum ApplicationStatus {
    DRAFT,
    SUBMITTED,
    UNDER_REVIEW,
    PENDING_DOCUMENTS,
    PENDING_KYC,
    APPROVED,
    REJECTED,
    CANCELLED;

    public static ApplicationStatus fromString(String status) {

        try {
            return ApplicationStatus.valueOf(status);
        } catch (IllegalArgumentException e) {
            // log
            throw new IllegalArgumentException("Invalid status");
        }

    }

    public static ApplicationStatus toEnumOrThrowError(String status) {
        return ApplicationStatus.valueOf(status);

    }

    // List of status to check for when an application is in-progress
    public static boolean isInProgress(ApplicationStatus status) {
        return status == DRAFT || status == SUBMITTED || status == PENDING_KYC
                || status == PENDING_DOCUMENTS || status == UNDER_REVIEW;
    }

    public static boolean isApproved(ApplicationStatus status) {
        return status == APPROVED;
    }

    public static boolean isRejected(ApplicationStatus status) {
        return status == REJECTED;
    }

    public static boolean isCancelled(ApplicationStatus status) {
        return status == CANCELLED;
    }

    public boolean canBeReapplied(ApplicationStatus status) {
        if (status == null) {
            return true;
        }
        if (isCancelled(status)) {
            return true;
        }
        if (isRejected(status)) {
            return true;
        }
        if (isApproved(status)) {
            return false;
        }
        if (isInProgress(status)) {
            return false;
        }
        return true;
    }

    public static List<ApplicationStatus> getInProgressStatuses() {
        return List.of(DRAFT, SUBMITTED, PENDING_KYC, PENDING_DOCUMENTS, UNDER_REVIEW);
    }

    public static List<ApplicationStatus> getStatusesToCheckDuplication() {
        return List.of(SUBMITTED,
                APPROVED,
                DRAFT,
                UNDER_REVIEW,
                PENDING_DOCUMENTS,
                PENDING_KYC);
    }

}
