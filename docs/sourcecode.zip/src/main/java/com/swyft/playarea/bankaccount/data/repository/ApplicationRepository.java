package com.swyft.playarea.bankaccount.data.repository;

import com.swyft.playarea.bankaccount.data.entities.Application;
import com.swyft.playarea.bankaccount.enums.ApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ApplicationRepository extends JpaRepository<Application, String> {

    List<Application> findByCustomerIdAndProductIdAndStatusIn(String customerId, String productId, List<ApplicationStatus> statuses);
    List<Application> findByCustomerIdAndProductId(String customerId, String productId);



}

